ApplicationLabel = Label():width(200):height(100):marginLeft(0):marginTop(TopBarHeight):lines(0):bgColor(Color(200, 180, 250, 1))
                       :textAlign(TextAlign.CENTER)
ApplicationLabel:text("测试Application  按下HOME键 来验证")
window:addView(ApplicationLabel)


Application:setForeground2BackgroundCallback(function()
    Toast('从 前台 到 后台 ------')
    print('从 前台 到 后台 ------')

end)


Application:setBackground2ForegroundCallback(function()
    Toast('从 后台 到 前台 =====')
    print('从 后台 到 前台 =====')

end)
