--requireConfig = require("RequireConfig")
--
--currentPageIndex = 0-- Demo当前页数
------添加 翻页按钮
--BtnLeft = Label():text("下一页"):fontSize(20):textColor(Color(255, 255, 255, 1)):width(MeasurementType.WRAP_CONTENT):height(MeasurementType.WRAP_CONTENT):bgColor(Color(0, 0, 0, 0.7)):padding(2, 4, 2, 4):setGravity(MBit:bor(Gravity.LEFT, Gravity.CENTER_VERTICAL))
--BtnRight = Label():text("上一页"):fontSize(20):textColor(Color(255, 255, 255, 1)):width(MeasurementType.WRAP_CONTENT):height(MeasurementType.WRAP_CONTENT):bgColor(Color(0, 0, 0, 0.5)):padding(2, 4, 2, 4):setGravity(MBit:bor(Gravity.RIGHT, Gravity.CENTER_VERTICAL))
--BtnLeft:onClick(function()
--    currentPageIndex = currentPageIndex + 1
--    changePage(currentPageIndex)
--end)
--BtnRight:onClick(function()
--    currentPageIndex = currentPageIndex - 1
--    if currentPageIndex < 1 then
--        currentPageIndex = 1
--    end
--    changePage(currentPageIndex)
--end)
--window:addView(BtnLeft)
----window:addView(BtnRight)
--
------通过pageIndex，切换不同Demo
--function changePage(pageIndex)
--
--    local demoPath = requireConfig.PathTable[pageIndex]
--    window:removeAllSubviews()
--    window:bgColor(Color(255,255,255,1))
--    window:addView(BtnLeft)
--    --window:addView(BtnRight)
--    if demoPath then
--        require(demoPath)
--    end
--
--    window:addView(BtnLeft)
--    --window:addView(BtnRight)
--end
--
----require('CollectionView.CollectionViewTestCase2')

local requireConfig = require("RequireConfig")

local screen_w = System:screenSize():width()
local screen_h = System:screenSize():height()
local topBar = System:stateBarHeight() + System:navBarHeight()

---创建tableview
local tableView = TableView(true, true)
if System:iOS() then
    tableView:frame(Rect(0, topBar, screen_w, screen_h - topBar))
else
    tableView:frame(Rect(0, 0, screen_w, screen_h))
end
window:addView(tableView)

local tableViewAdapter = TableViewAdapter()
tableViewAdapter:sectionCount(function()
    return 1
end)
tableViewAdapter:rowCount(function(section)
    return #requireConfig.PathTable
end)
tableViewAdapter:heightForCell(function(section, row)
    return 30
end)
tableViewAdapter:initCell(function(cell)
    cell.contentView:bgColor(Color(0, 191, 255, 1)):cornerRadius(12)
    cell.textLabel = Label():setGravity(Gravity.CENTER):width(MeasurementType.WRAP_CONTENT):height(30):lines(0):textAlign(TextAlign.CENTER)
    cell.contentView:addView(cell.textLabel)
end)
tableViewAdapter:fillCellData(function(cell, section, row)
    cell.textLabel:text(requireConfig.PathTable[row])
end)
tableViewAdapter:selectedRow(function(cell, section, row)
    --require('Alert0Switch.AlertAndSwitch')
    changePage(row)
end)
tableView:setRefreshingCallback(function()
    System:setTimeOut(function()
        tableView:stopRefreshing()
        tableView:reloadData()
    end, 2)
end)
tableView:setLoadingCallback(function()
    System:setTimeOut(function()
        tableView:stopLoading()
        tableView:noMoreData()
    end, 2)
end)
tableView:adapter(tableViewAdapter)

---添加按钮，用来关闭当前view用例，返回tableview
local topBar = System:navBarHeight() + System:stateBarHeight()
local label = Label():bgColor(Color(255, 255, 0, 1)):cornerRadius(10)
if System:iOS() then
    label:frame(Rect(screen_w - 110, screen_h / 2, 120, 50))
else
    label:frame(Rect(screen_w - 110, screen_h / 2, 120, 50))
end

label:text('返回用例列表'):textAlign(TextAlign.CENTER):fontSize(18):textColor(Color(255, 0, 0, 1))
label:onClick(function()
    -----隐藏
    --tableView:gone(false)
    --label:gone(true)
    --window:bringSubviewToFront(tableView)
    window:removeAllSubviews()
    window:addView(tableView)
end)


----通过pageIndex，切换不同Demo

function changePage(pageIndex)
    local demoPath = requireConfig.PathTable[pageIndex]
    -----隐藏
    --tableView:gone(true)
    --window:bgColor(Color(255,255,255,1))
    --label:gone(false)
    window:removeAllSubviews()
    window:bgColor(Color(255, 255, 255, 1))
    if demoPath then
        require(demoPath)
    end
    window:addView(label)
end




