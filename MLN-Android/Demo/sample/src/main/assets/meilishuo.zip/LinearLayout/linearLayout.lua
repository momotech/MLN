if System:iOS() then
    endtopHeight = window:navBarHeight()+window:statusBarHeight()
else
    endtopHeight = 0
end
scrollView = ScrollView():width(MeasurementType.MATCH_PARENT)
                         :height(MeasurementType.MATCH_PARENT)
                         :bgColor(Color(200, 120, 120, 1))
                         :showsVerticalScrollIndicator(false)
                         :marginTop(endtopHeight)

linearlayout = LinearLayout(LinearType.VERTICAL)

linearlayout:width(MeasurementType.WRAP_CONTENT):height(MeasurementType.WRAP_CONTENT)
linearlayout:marginTop(3)
linearlayout:marginLeft(3)
linearlayout:bgColor(Color(200, 180, 250, 1))
linearlayout:alpha(0.5)
linearlayout:clipToBounds(true)

tagLabel = Label()
tagLabel:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):padding(1, 9, 1, 9):bgColor(Color(0xff, 0xcd, 0x00, 1)):cornerRadius(8)
tagLabel:text('被插入的Label 视图')

-- 插入视图到指定位置
insertView = Label():textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(16)
insertView:text('在第二个位置 插入 Label 视图')

insertView:onClick(function()
    linearlayout:insertView(tagLabel, 1)
    linearlayout:requestLayout()
end)

-- 添加border
addBorderLabel = Label():textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
addBorderLabel:text('添加 borderWidth(3) ')
addBorderLabel:onClick(function()
    linearlayout:borderWidth(3)
    linearlayout:borderColor(Color(25, 80, 49, 1))
    linearlayout:requestLayout()
    Toast(' 点击添加borderWidth(3)')
end)

-- 根据frame 动态调整linearlayout 大小
frameLabel = Label():textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
frameLabel:text('根据frame 动态调整 大小 ')
frameLabel:onClick(function()
    linearlayout:frame(Rect(15, 20, 300, 300))
    Toast('根据frame 动态调整 大小 ')
end)

-- 设置 gradientColor 渐变色
gradientColorLabel = Label():textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
gradientColorLabel:text('设置纵向 gradientColor 渐变色 ')
gradientColorLabel:onClick(function()
    linearlayout:setGradientColor(Color(200, 180, 250, 1), Color(200, 120, 120, 1), true)
end)

-- 动态调整 cornerRadius 大小
cornerRadiusLabel = Label():textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
cornerRadiusLabel:text('动态 调整 linearlayout 圆角大小 ')
cornerRadiusLabel:onClick(function()
    linearlayout:cornerRadius(15)
    Toast('圆角大小 15 ')
end)


-- removeFromSuper
removeFromSuperLabel = Label()
removeFromSuperLabel:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
removeFromSuperLabel:text('父视图中移除linearlayout ')

removeFromSuperLabel:onClick(function()
    linearlayout:removeFromSuper()
end)


-- 清除子视图
removeAllSubviewsLabel = Label()
removeAllSubviewsLabel:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
removeAllSubviewsLabel:text('清除所有子视图')

removeAllSubviewsLabel:onClick(function()
    -- linearlayout:removeFromSuper()
    linearlayout:removeAllSubviews()
end)

-- 获取centerX centerY值
centerX = Label()
centerX:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
centerX:text('点击 获取 centerX 数值')

centerX:onClick(function()
    centerX:text('centerX = ' .. tostring(linearlayout:centerX()) .. '   centerY = ' .. tostring(linearlayout:centerY()))
end)

-- convertPointTo 值
convertPointTo = Label()
convertPointTo:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
convertPointTo:text('调用convertPointTo()')

convertPointTo:onClick(function()
    local point = linearlayout:convertPointTo(centerX, Point(20, 20))
    Toast('  pointX = ' .. tostring(point:x()) .. '  pointY = ' .. tostring(point:y()))
end)

-- setGravity 值
setGravityLabel = Label()
setGravityLabel:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
setGravityLabel:text('  setGravity  来设置位置到右侧')

setGravityLabel:onClick(function()
    scrollView:height(200)
    scrollView:width(150)

    linearlayout:setGravity(Gravity.RIGHT)
    scrollView:setGravity(Gravity.RIGHT)
end)

-- 设置 padding( top,  right,  bottom, left)
paddingLabel = Label()
paddingLabel:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
paddingLabel:text(' 设置 padding ')

paddingLabel:onClick(function()
    linearlayout:padding(10, 5, 20, 13)
    Toast('设置 padding')
end)


-- setWrapContent(true)
setWrapContentLabel = Label()
setWrapContentLabel:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
setWrapContentLabel:text(' 包裹内容 setWrapContent(true) ')

setWrapContentLabel:onClick(function()
    linearlayout:setWrapContent(true)
end)

-- openRipple(true)
openRipple = true
openRippleLabel = Label()
openRippleLabel:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
openRippleLabel:text(' 水波纹 openRipple() ')

openRippleLabel:onClick(function()
    if openRipple then
        linearlayout:openRipple(true)
        openRippleLabel:text(' 水波纹 openRipple(true) ')
        openRipple = false
    else
        linearlayout:openRipple(false)
        openRippleLabel:text(' 水波纹 openRipple(false) ')
        openRipple = true
    end
    Toast('点击 水波纹 文案')
end)

-- hidden(true)
hiddenLabel = Label()
hiddenLabel:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
hiddenLabel:text(' 隐藏 hidden(true) ')

hiddenLabel:onClick(function()
    linearlayout:hidden(true)
end)


-- 改变  bgColor()
bgColorLabel = Label()
bgColorLabel:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
bgColorLabel:text('改变背景色 bgColor() ')

bgColorLabel:onClick(function()
    linearlayout:bgColor(Color(30, 40, 50, 1))
end)

-- 是否 禁止用户交互 enabled
enabled = false
enabledLabel = Label()
enabledLabel:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
enabledLabel:text('是否 禁止用户交互 enabled ')

enabledLabel:onClick(function()
    if enabled then
        linearlayout:enabled(true)
        enabledLabel:text('当前linearlayout 可以点击 true ')

        enabled = false
    else
        linearlayout:enabled(false)
        enabledLabel:text('当前linearlayout 不可以点击 false ')

        enabled = true
    end
end)

-- 设置点击回调
onClickLabel = Label()
onClickLabel:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
onClickLabel:text('设置点击回调 ')

onClickLabel:onClick(function()
    linearlayout:onClick(function()
        Toast('linearlayout onClick')
    end)
    Toast('设置点击回调')
end)

-- 设置长按回调
onLongPressLabel = Label()
onLongPressLabel:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
onLongPressLabel:text('设置长按回调 ')

onLongPressLabel:onClick(function()
    linearlayout:onLongPress(function()
        Toast('linearlayout 长按回调')
    end)
    Toast('设置长按回调')

end)

-- 重新绘制
requestLayoutLabel = Label()
requestLayoutLabel:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
requestLayoutLabel:text('重新绘制 requestLayout')

requestLayoutLabel:onClick(function()
    linearlayout:requestLayout()
    Toast('重新绘制')
end)

-- 设置margin
marginLabel = Label()
marginLabel:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
marginLabel:text('设置 x() y()')

marginLabel:onClick(function()
    linearlayout:x(10):y(20)
    Toast('设置 x(10)   y(20)')
end)

-- 设置 notClipLabel
notClipLabel = Label()
notClipLabel:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
notClipLabel:text('设置 notClip（true）')

notClipLabel:onClick(function()
    linearlayout:notClip(true)
    Toast('设置 notClip（true）')
end)

-- 设置 addCornerMask
addCornerMaskLabel = Label()
addCornerMaskLabel:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
addCornerMaskLabel:text('设置 addCornerMask')

addCornerMaskLabel:onClick(function()
    linearlayout:addCornerMask(45, Color(30, 40, 50, 1), MBit:bor(RectCorner.BOTTOM_RIGHT, RectCorner.BOTTOM_LEFT, RectCorner.TOP_RIGHT, RectCorner.TOP_LEFT))
    Toast('设置 addCornerMask')
end)

-- 设置 hasFocusLabel
hasFocusLabel = Label()
hasFocusLabel:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
hasFocusLabel:text('判断 hasFocus()')

hasFocusLabel:onClick(function()
    Toast('判断 hasFocus() = ' .. tostring(linearlayout:hasFocus()))
end)

-- 设置 alpha 值
alpha = 0;
alphaLabel = Label()
alphaLabel:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
alphaLabel:text('设置 alpha 值')

alphaLabel:onClick(function()
    if alpha == 0 then
        linearlayout:alpha(1)
        alpha = 1
    else
        linearlayout:alpha(0)
        alpha = 0
    end

    alphaLabel:text('alpha = ' .. tostring(alpha))
    Toast('alpha = ' .. tostring(alpha))
end)
--
---- 设置 sizeToFit()废弃
--sizeToFitLabel = Label()
--sizeToFitLabel:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
--sizeToFitLabel:text('设置 sizeToFit()')
--
--sizeToFitLabel:onClick(function()
--    linearlayout:sizeToFit()
--    Toast('调用linearlayout  sizeToFit()')
--end)
--
---- 设置 layoutIfNeeded()废弃
--layoutIfNeededLabel = Label()
--layoutIfNeededLabel:textColor(Color(0x73, 0x00, 0x00, 1)):fontSize(20):marginTop(20)
--layoutIfNeededLabel:text('设置 layoutIfNeeded()')
--
--layoutIfNeededLabel:onClick(function()
--    linearlayout:layoutIfNeeded()
--    Toast('调用linearlayout  layoutIfNeeded()')
--end)

linearlayout:addView(insertView)
linearlayout:addView(addBorderLabel)
linearlayout:addView(frameLabel)
linearlayout:addView(gradientColorLabel)
linearlayout:addView(cornerRadiusLabel)
linearlayout:addView(removeAllSubviewsLabel)
linearlayout:addView(removeFromSuperLabel)
linearlayout:addView(centerX)
linearlayout:addView(convertPointTo)
linearlayout:addView(setGravityLabel)
linearlayout:addView(paddingLabel)
linearlayout:addView(setWrapContentLabel)
linearlayout:addView(openRippleLabel)
linearlayout:addView(hiddenLabel)
linearlayout:addView(bgColorLabel)
linearlayout:addView(enabledLabel)
linearlayout:addView(onClickLabel)
linearlayout:addView(onLongPressLabel)
linearlayout:addView(requestLayoutLabel)
linearlayout:addView(marginLabel)
linearlayout:addView(notClipLabel)
linearlayout:addView(addCornerMaskLabel)
linearlayout:addView(hasFocusLabel)
linearlayout:addView(alphaLabel)

scrollView:addView(linearlayout)
window:addView(scrollView)
