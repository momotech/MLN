local MLSwitch = require("MLSwitch.MLSwitch.MLSwitch")
local ActionsBar =  require("lua_pods.MLNActionsBar.ActionsBar")

local switch = MLSwitch:new()
local isOn = true

local bar = ActionsBar:new(nil):useDefaultSetting()
window:addView(bar.contentScroll)
local titles = {"on(true)",
                "on(false)",
                ":width(100):height(30)",
                ":width(300):height(100)",
                ":setNormalColor(Color(255,0,0,1))",
                ":setNormalColor(Color(255,0,255,1))",
                ":setSelectedColor(Color(155,0,155,1))",
                ":setSelectedColor(Color(0,0,255,1))",
                ":setThumbColor(Color(211,45,121,1.0))"
}

bar:setupTitles(titles)

bar:onClick(function(index,label)
    if  index == 1 then
        switch:on(true)
    elseif  index == 2 then
        switch:on(false)
    elseif index == 3 then
        switch:width(100):height(30)
    elseif index == 4 then
        switch:width(300):height(100)
    elseif index == 5 then
        switch:setNormalColor(Color(255,0,0,1))
    elseif index == 6 then
        switch:setNormalColor(Color(255,0,255,1))
    elseif index == 7 then
        switch:setSelectedColor(Color(155,0,155,1))
    elseif index == 8 then
        switch:setSelectedColor(Color(0,0,255,1))
    elseif index == 9 then
        switch:setThumbColor(Color(211,45,121,1.0))
    end

end)



--switch:layoutWithSize(Size(100,50))
switch:setGravity(Gravity.CENTER):marginLeft(20):marginTop(50):width(300):height(100)
window:addView(switch.switchView)

switch:setSwitchChangedCallback(function(isOn)
    Toast("switch isOn:" .. tostring(isOn),1)
end)

window:onClick(function()
    switch:on(isOn)
    isOn = (isOn == false)
end)

local switch2 = MLSwitch:new()
switch2:marginTop(200):marginLeft(20)
window:addView(switch2.switchView)

switch2:setSwitchChangedCallback(function(isOn)
    Toast("switch2 isOn:" .. tostring(isOn), 1)
end)

