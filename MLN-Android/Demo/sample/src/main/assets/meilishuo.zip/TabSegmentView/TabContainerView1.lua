--[[
    * 视图层级说明

    * window
    * --containerView TabContainerView中的顶层视图
    * ----contentView 内容视图，用于显示子ViewController（Activity）的视图
    * ----tabToolBar tab选项卡视图
--]]

--TabToolBar = require('TabToolBar')
TabToolBar = require('TabSegmentView.TabToolBar')

local windowHeight = window:height()
local windowWidth = window:width()

containerView = View()
containerView:bgColor(Color(25,255,255,1)):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT)
window:addView(containerView)


contentView = View()
contentView:bgColor(Color(255,255,255,1)):width(300):height(300):setGravity(Gravity.CENTER_HORIZONTAL):marginTop(100)
containerView:addView(contentView)

local firstView = View():bgColor(Color(100,238,255,1)):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT)
local secondView = View():bgColor(Color(125,155,255,1)):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT)
local thirdView = View():bgColor(Color(0,0,255,1)):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT)
local fourthView = View():bgColor(Color(22,255,11,1)):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT)
local fifthView = View():bgColor(Color(125,255,155,1)):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT)
local subViews = {firstView, secondView, thirdView, fourthView, fifthView}

contentView:addView(subViews[1])

local tabbar = TabToolBar:new()
local images = Array()
images:add("标题1")
images:add("标题二")
images:add("标题二")
images:add("标题二")
images:add("标题二")
tabbar:setupItems(images, function(idx)
    print(">>>>>> idx "..tostring(idx))

    contentView:removeAllSubviews()
    if idx == 1 then
        contentView:addView(subViews[idx])
    elseif idx == 2 then
        contentView:addView(subViews[idx])
    elseif idx == 3 then
        contentView:addView(subViews[idx])
    elseif idx == 4 then
        contentView:addView(subViews[idx])
    elseif idx == 5 then
        contentView:addView(subViews[idx])
    end

end)
containerView:addView(tabbar.contentView)

