TabToolBar = require('TabSegmentView.TabToolBar')
local tabbar = TabToolBar:new()

--TODO

local images = Array()
images:add("标题1")
images:add("标题二")
images:add("标题二")
images:add("标题二")
images:add("标题二")
tabbar:setupItems(images, function(idx)
     print(">>>>>> idx "..tostring(idx))
end)
window:addView(tabbar.contentView)
