--[[
    * 视图层级说明

    * window
    * --containerView TabContainerView中的顶层视图
    * ----contentView 内容视图，用于显示子ViewController（Activity）的视图
    * ----tabToolBar tab选项卡视图
--]]



focusViewDataSource = {Color(25,255,255,1), Color(134,166,12,1)}

focusContainerView = View()
focusContainerView:bgColor(Color(255,255,255,1)):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT):marginTop(0)

local titles = Array()
titles:add("关注")
titles:add("推荐")

--Setup TabBarSegment
local tabSegmentPositionY = 0
local tabSegmentHeight = 50

tabSegment = TabSegmentView(Rect(0, tabSegmentPositionY,window:width(),tabSegmentHeight),titles,Color(0,0,0,1.0)):selectScale(1.0):width(MeasurementType.MATCH_PARENT):setAlignment(TabSegmentAlignment.CENTER):setGravity(Gravity.CENTER_HORIZONTAL)
tabSegment:bgColor(Color(255,255,255,1.0))
tabSegment:setAlignment(TabSegmentAlignment.CENTER)

focusContainerView:addView(tabSegment)
--tabSegment:normalFontSize(18)
tabSegment:setItemTabClickListener(function(index)
    print("Click",index)

end)

--Setup ViewPagerAdapter
adapter = ViewPagerAdapter()
adapter:getCount(function(section)
    return #focusViewDataSource
end)

adapter:initCell(function(cell,row)
    local contentView = cell.contentView
    contentView:bgColor(Color(255, 255, 255, 1))
end)
adapter:fillCellData(function(cell,row)
    local contentView = cell.contentView
    local width = contentView:width()
    local height = contentView:height()
    contentView:bgColor(focusViewDataSource[row])
end)

-- Setup ViewPager
viewPager = ViewPager()
viewPager:scrollToPage(1,false)

viewPager:endDragging(function(row)
    print('停止滚动了----',row)
end)

local viewPagerMarginTop = tabSegmentPositionY + tabSegmentHeight

viewPager:marginTop(viewPagerMarginTop):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT):setGravity(Gravity.CENTER_HORIZONTAL)

viewPager:showIndicator(false)

viewPager:adapter(adapter)

tabSegment:relatedToViewPager(viewPager,true)

focusContainerView:addView(viewPager)





discoverDataSource = {Color(233,139,42,1)}

discoverContainerView = View()
discoverContainerView:bgColor(Color(34,66,121,1)):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT):marginTop(0)

local titles = Array()
titles:add("发现")

--Setup TabBarSegment
local tabSegmentPositionY = 0
local tabSegmentHeight = 50

tabSegment = TabSegmentView(Rect(0, tabSegmentPositionY,window:width(),tabSegmentHeight),titles,Color(0,0,0,1.0)):selectScale(1.0):width(MeasurementType.MATCH_PARENT):setAlignment(TabSegmentAlignment.CENTER):setGravity(Gravity.CENTER_HORIZONTAL)
tabSegment:bgColor(Color(255,255,255,1.0))
tabSegment:setAlignment(TabSegmentAlignment.CENTER)

discoverContainerView:addView(tabSegment)
--tabSegment:normalFontSize(18)
tabSegment:setItemTabClickListener(function(index)
    print("Click",index)

end)

--Setup ViewPagerAdapter
adapter = ViewPagerAdapter()
adapter:getCount(function(section)
    return #discoverDataSource
end)

adapter:initCell(function(cell,row)
    local contentView = cell.contentView
    contentView:bgColor(Color(255, 255, 255, 1))
end)
adapter:fillCellData(function(cell,row)
    local contentView = cell.contentView
    local width = contentView:width()
    local height = contentView:height()
    contentView:bgColor(discoverDataSource[row])
end)

-- Setup ViewPager
viewPager = ViewPager()
viewPager:scrollToPage(1,false)

viewPager:endDragging(function(row)
    print('停止滚动了----',row)
end)

local viewPagerMarginTop = tabSegmentPositionY + tabSegmentHeight

viewPager:marginTop(viewPagerMarginTop):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT):setGravity(Gravity.CENTER_HORIZONTAL)

viewPager:showIndicator(false)

viewPager:adapter(adapter)

tabSegment:relatedToViewPager(viewPager,true)

discoverContainerView:addView(viewPager)




placeholerDataSource = {Color(67,52,27,1)}

placeholerContainerView = View()
placeholerContainerView:bgColor(Color(34,66,121,1)):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT):marginTop(0)

local titles = Array()
titles:add("占位页")

--Setup TabBarSegment
local tabSegmentPositionY = 0
local tabSegmentHeight = 50

tabSegment = TabSegmentView(Rect(0, tabSegmentPositionY,window:width(),tabSegmentHeight),titles,Color(0,0,0,1.0)):selectScale(1.0):width(MeasurementType.MATCH_PARENT):setAlignment(TabSegmentAlignment.CENTER):setGravity(Gravity.CENTER_HORIZONTAL)
tabSegment:bgColor(Color(255,255,255,1.0))
tabSegment:setAlignment(TabSegmentAlignment.CENTER)

placeholerContainerView:addView(tabSegment)
--tabSegment:normalFontSize(18)
tabSegment:setItemTabClickListener(function(index)
    print("Click",index)

end)

--Setup ViewPagerAdapter
adapter = ViewPagerAdapter()
adapter:getCount(function(section)
    return #placeholerDataSource
end)

adapter:initCell(function(cell,row)
    local contentView = cell.contentView
    contentView:bgColor(Color(255, 255, 255, 1))
end)
adapter:fillCellData(function(cell,row)
    local contentView = cell.contentView
    local width = contentView:width()
    local height = contentView:height()
    contentView:bgColor(placeholerDataSource[row])
end)

-- Setup ViewPager
viewPager = ViewPager()
viewPager:scrollToPage(1,false)

viewPager:endDragging(function(row)
    print('停止滚动了----',row)
end)

local viewPagerMarginTop = tabSegmentPositionY + tabSegmentHeight

viewPager:marginTop(viewPagerMarginTop):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT):setGravity(Gravity.CENTER_HORIZONTAL)

viewPager:showIndicator(false)

viewPager:adapter(adapter)

tabSegment:relatedToViewPager(viewPager,true)

placeholerContainerView:addView(viewPager)




messageDataSource = {Color(125,255,155,1)}

messageContainerView = View()
messageContainerView:bgColor(Color(34,66,121,1)):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT):marginTop(0)

local titles = Array()
titles:add("消息")

--Setup TabBarSegment
local tabSegmentPositionY = 0
local tabSegmentHeight = 50

tabSegment = TabSegmentView(Rect(0, tabSegmentPositionY,window:width(),tabSegmentHeight),titles,Color(0,0,0,1.0)):selectScale(1.0):width(MeasurementType.MATCH_PARENT):setAlignment(TabSegmentAlignment.CENTER):setGravity(Gravity.CENTER_HORIZONTAL)
tabSegment:bgColor(Color(255,255,255,1.0))
tabSegment:setAlignment(TabSegmentAlignment.CENTER)

messageContainerView:addView(tabSegment)
--tabSegment:normalFontSize(18)
tabSegment:setItemTabClickListener(function(index)
    print("Click",index)

end)

--Setup ViewPagerAdapter
adapter = ViewPagerAdapter()
adapter:getCount(function(section)
    return #messageDataSource
end)

adapter:initCell(function(cell,row)
    local contentView = cell.contentView
    contentView:bgColor(Color(255, 255, 255, 1))
end)
adapter:fillCellData(function(cell,row)
    local contentView = cell.contentView
    local width = contentView:width()
    local height = contentView:height()
    contentView:bgColor(messageDataSource[row])
end)

-- Setup ViewPager
viewPager = ViewPager()
viewPager:scrollToPage(1,false)

viewPager:endDragging(function(row)
    print('停止滚动了----',row)
end)

local viewPagerMarginTop = tabSegmentPositionY + tabSegmentHeight

viewPager:marginTop(viewPagerMarginTop):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT):setGravity(Gravity.CENTER_HORIZONTAL)

viewPager:showIndicator(false)

viewPager:adapter(adapter)

tabSegment:relatedToViewPager(viewPager,true)

messageContainerView:addView(viewPager)





mineDataSource = {Color(247,92,47,1)}

mineContainerView = View()
mineContainerView:bgColor(Color(34,66,121,1)):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT):marginTop(0)

local titles = Array()
titles:add("消息")

--Setup TabBarSegment
local tabSegmentPositionY = 0
local tabSegmentHeight = 50

tabSegment = TabSegmentView(Rect(0, tabSegmentPositionY,window:width(),tabSegmentHeight),titles,Color(0,0,0,1.0)):selectScale(1.0):width(MeasurementType.MATCH_PARENT):setAlignment(TabSegmentAlignment.CENTER):setGravity(Gravity.CENTER_HORIZONTAL)
tabSegment:bgColor(Color(255,255,255,1.0))
tabSegment:setAlignment(TabSegmentAlignment.CENTER)

mineContainerView:addView(tabSegment)
--tabSegment:normalFontSize(18)
tabSegment:setItemTabClickListener(function(index)
    print("Click",index)

end)

--Setup ViewPagerAdapter
adapter = ViewPagerAdapter()
adapter:getCount(function(section)
    return #mineDataSource
end)

adapter:initCell(function(cell,row)
    local contentView = cell.contentView
    contentView:bgColor(Color(255, 255, 255, 1))
end)
adapter:fillCellData(function(cell,row)
    local contentView = cell.contentView
    local width = contentView:width()
    local height = contentView:height()
    contentView:bgColor(mineDataSource[row])
end)

-- Setup ViewPager
viewPager = ViewPager()
viewPager:scrollToPage(1,false)

viewPager:endDragging(function(row)
    print('停止滚动了----',row)
end)

local viewPagerMarginTop = tabSegmentPositionY + tabSegmentHeight

viewPager:marginTop(viewPagerMarginTop):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT):setGravity(Gravity.CENTER_HORIZONTAL)

viewPager:showIndicator(false)

viewPager:adapter(adapter)

tabSegment:relatedToViewPager(viewPager,true)

mineContainerView:addView(viewPager)


TabToolBar = require('TabSegmentView.TabToolBar')
--TabToolBar = require('TabToolBar')
HomePagerView = require('TabSegmentView.HomePagerView')

local windowHeight = window:height()
local windowWidth = window:width()

containerView = View()
containerView:bgColor(Color(255,255,255,1)):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT)
window:addView(containerView)

contentViewMarginTop = window:statusBarHeight()
contentView = View()
contentView:bgColor(Color(255,255,255,1)):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT):setGravity(Gravity.CENTER_HORIZONTAL):marginTop(contentViewMarginTop)
containerView:addView(contentView)

local homeView = HomePagerView:new():homeView()
local secondView = View():bgColor(Color(125,155,255,1)):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT)
local thirdView = View():bgColor(Color(0,0,255,1)):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT)
local fourthView = View():bgColor(Color(22,255,11,1)):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT)
local fifthView = View():bgColor(Color(125,255,155,1)):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT)
local subViews = {homeView, discoverContainerView, placeholerContainerView, messageContainerView, mineContainerView}

contentView:addView(subViews[1])

local tabbar = TabToolBar:new()
local images = Array()
images:add("标题1")
images:add("标题二")
images:add("标题二")
images:add("标题二")
images:add("标题二")
tabbar:setupItems(images, function(idx)
    print(">>>>>> idx "..tostring(idx))

    contentView:removeAllSubviews()
    if idx == 1 then
        contentView:addView(subViews[idx])
    elseif idx == 2 then
        contentView:addView(subViews[idx])
    elseif idx == 3 then
        contentView:addView(subViews[idx])
    elseif idx == 4 then
        contentView:addView(subViews[idx])
    elseif idx == 5 then
        contentView:addView(subViews[idx])
    end

end)
containerView:addView(tabbar.contentView)

