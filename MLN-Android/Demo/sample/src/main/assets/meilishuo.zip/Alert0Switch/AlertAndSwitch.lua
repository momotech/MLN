local _class = {}
_class._version = '1.0'
_class._classname = 'AlertDemo'

function _class:onCreate(window)
    local ActionBar = require("common_actionbar.VerActionBar")
    local actionBar = ActionBar:new(nil):useDefaultSetting()
    local topHeight = System:navBarHeight() + System:stateBarHeight()
    actionBar.contentScroll:marginTop(topHeight + 250)
    local titles = { "setThumbColor", "setNormalColor",
                     "setSelectedColor" }
    actionBar:setupTitles(titles)
    actionBar:onClick(function(index, label)
        if index == 1 then
            switch2:setThumbColor(Color(255, 0, 0, 0.5))
        elseif index == 2 then
            switch2:setNormalColor(Color(255, 255, 0, 0.5))
        elseif index == 3 then
            switch2:setSelectedColor(Color(0, 255, 255, 0.5))
        end
    end)
    window:addView(actionBar.contentScroll)

    local label1 = Label()
    label1:text("常规取消确认提示")

    label1:frame(Rect(20, 100, 150, 33))

    label1:bgColor(Color(121, 121, 121, 1.0))

    window:addView(label1)

    label1:onClick(function()
        local alert = Alert()
        alert:title("我是标题")
        alert:message("我是消息啦！！")

        alert:setCancel("取消按钮", function()
            print("点击了取消按钮！")
        end)

        alert:setOk("ok按钮", function()
            print("点击啦OK按钮" .. alert:title() .. "*" .. alert:message())

        end)

        alert:show()

    end)

    local label2 = Label()
    label2:text("竖排多按钮")

    label2:frame(Rect(20, 150, 150, 33))

    label2:bgColor(Color(121, 121, 121, 1.0))

    window:addView(label2)

    label2:onClick(function()
        local alert = Alert()
        alert:title("我是标题")
        alert:message("我是消息啦！！")

        local btns = Array()
        btns:add("按钮1")
        btns:add("按钮2")
        btns:add("按钮3")
        btns:add("按钮4")
        btns:add("按钮5")

        alert:setButtonList(btns, function(number)
            print("点击了按钮", btns:get(number))
        end)

        alert:show()

    end)

    local label3 = Label()
    label3:text("单个按钮文案和回调")

    label3:frame(Rect(20, 200, 150, 33))

    label3:bgColor(Color(121, 121, 121, 1.0))

    window:addView(label3)

    label3:onClick(function()
        local alert = Alert()
        alert:title("我是标题")
        alert:message("2秒后dismiss")

        alert:setSingleButton("就我啦", function()
            print("点击了就我啦按钮")
        end)

        alert:show()
        System:setTimeOut(function()
            alert:dismiss()
        end, 2)
    end)

    switch2 = Switch():width(50):height(30):x(20):y(250)
    switch2:setSwitchChangedCallback(function(isOn)
        Toast("switch2:" .. tostring(switch2:on()), 2)
    end)
    window:addView(switch2)
end

_class:onCreate(window)

return _class

