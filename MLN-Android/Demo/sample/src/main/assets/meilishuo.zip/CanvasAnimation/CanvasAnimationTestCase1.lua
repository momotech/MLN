local trans1 = TranslateAnimation(0,200,0,0):setDuration(10):setInterpolator(InterpolatorType.Bounce)
local anim = Animation():setTranslateX(0,200):setDuration(10):setInterpolator(InterpolatorType.Bounce)
local view = View():bgColor(Color(121,112,111,1.0)):width(50):height(50):marginTop(120)
window:addView(view)

local label1 = Label():text("开始"):width(50):height(MeasurementType.MATCH_PARENT):bgColor(Color(255,0,255,1.0))
local label4 = Label():text("取消"):width(50):height(MeasurementType.MATCH_PARENT):bgColor(Color(255,0,255,1.0))

local linear = LinearLayout():marginTop(200):width(MeasurementType.MATCH_PARENT):height(30)

linear:addView(label1)
linear:addView(label4)

window:addView(linear)

label1:onClick(function()
    view:startAnimation(trans1)
end)


label4:onClick(function()
    trans1:cancel()
end)


local linear2 = LinearLayout(LinearType.VERTICAL):marginTop(250):width(MeasurementType.WRAP_CONTENT):height(MeasurementType.WRAP_CONTENT)
window:addView(linear2)

local inter1 = Label():text("Linear(线性)"):height(30):bgColor(Color(255,0,255,1.0)):marginTop(10)
local inter2 = Label():text("Accelerate(加速)"):height(30):bgColor(Color(255,0,255,1.0)):marginTop(10)
local inter3 = Label():text("Decelerate(减速)"):height(30):bgColor(Color(255,0,255,1.0)):marginTop(10)
local inter4 = Label():text("AccelerateDecelerate(加速减速)"):height(30):bgColor(Color(255,0,255,1.0)):marginTop(10)
local inter5 = Label():text("Overshoot(超出)"):height(30):bgColor(Color(255,0,255,1.0)):marginTop(10)
local inter6 = Label():text("Bounce(弹性)"):height(30):bgColor(Color(255,0,255,1.0)):marginTop(10)

linear2:addView(inter1)
linear2:addView(inter2)
linear2:addView(inter3)
linear2:addView(inter4)
linear2:addView(inter5)
linear2:addView(inter6)

inter1:onClick(function()
    trans1:setInterpolator(InterpolatorType.Linear)
    Toast("Linear",1)
end)

inter2:onClick(function()
    trans1:setInterpolator(InterpolatorType.Accelerate)
    Toast("Accelerate",1)
end)

inter3:onClick(function()
    trans1:setInterpolator(InterpolatorType.Decelerate)
    Toast("Decelerate",1)
end)

inter4:onClick(function()
    trans1:setInterpolator(InterpolatorType.AccelerateDecelerate)
    Toast("AccelerateDecelerate",1)
end)

inter5:onClick(function()
    trans1:setInterpolator(InterpolatorType.Overshoot)
    Toast("Overshoot",1)
end)

inter6:onClick(function()
    trans1:setInterpolator(InterpolatorType.Bounce)
    Toast("Bounce",1)
end)
