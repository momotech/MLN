local _class = {}
_class._version = '1.0'
_class._classname = 'File'

local contentView = window

local width = contentView:width()
local height = contentView:height()

local showLabel = EditTextView()--显示结果


function _class:exist(filePath)
    local exist = File:exist(filePath)
    local text = "exist: " .. tostring(exist) .. "\n\nPath: " .. filePath
    showLabel:text(text)
    return text
end

function _class:isDir(filePath)
    local exist = File:isDir(filePath)
    showLabel:text("isDir: " .. tostring(exist) .. "\n\nPath: " .. filePath)
end

function _class:isFile(filePath)
    local exist = File:isFile(filePath)
    showLabel:text("isFile: " .. tostring(exist) .. "\n\nPath: " .. filePath)
end

function _class:asyncReadFile(filePath)
    File:asyncReadFile(filePath, function(codeNumber, file)
        showLabel:text("codeNumber: " .. tostring(codeNumber) .. "\n\nfileData: " .. tostring(file) .. "\n\nPath: " .. filePath)

    end)
end

function _class:syncReadTextFromAsset(filePath)
    syncReadTextFromAssetResult = File:syncReadTextFromAsset(filePath)

    showLabel:text("\n\n syncReadTextFromAssetResult =  " .. tostring(syncReadTextFromAssetResult))

end

function _class:syncWriteTextToAsset(filePath, value)
    syncWriteTextToAssetResult = File:syncWriteTextToAsset(filePath, value)

    showLabel:text("\n\n syncWriteTextToAssetResult =  " .. tostring(syncWriteTextToAssetResult))

end

function _class:syncReadMap(filePath)
    syncReadMapResult = File:syncReadMap(filePath)

    showLabel:text("\n\n syncReadMapResult =  " .. tostring(syncReadMapResult))

end

function _class:asyncReadMapFile(filePath)
    File:asyncReadMapFile(filePath, function(codeNumber, fileMap)
        showLabel:text("codeNumber: " .. tostring(codeNumber) .. "\n\nfileMap: " .. tostring(fileMap) .. "\n\nPath: " .. filePath)

    end)
end

function _class:syncReadArray(filePath)
    syncReadArrayResult = File:syncReadArray(filePath)
    showLabel:text("syncReadArrayResult = " .. tostring(syncReadArrayResult))
end

function _class:asyncReadArrayFile(filePath)
    File:asyncReadArrayFile(filePath, function(codeNumber, fileArray)
        showLabel:text("codeNumber: " .. tostring(codeNumber) .. "\n\nfileArray: " .. tostring(fileArray) .. "\n\nPath: " .. filePath)

    end)
end

function _class:asyncWriteFile(filePath, str)
    File:asyncWriteFile(filePath, str, function(codeNumber, path)
        showLabel:text("codeNumber: " .. tostring(codeNumber) .. "\n\ncallBackPath: " .. tostring(path) .. "\n\nPath: " .. filePath .. "\n\nstr: " .. str)
    end)
end

function _class:asyncWriteMap(filePath, map)
    File:asyncWriteMap(filePath, map, function(codeNumber, path)
        showLabel:text("codeNumber: " .. tostring(codeNumber) .. "\n\ncallBackPath: " .. tostring(path) .. "\n\nPath: " .. filePath .. "\n\nmap: " .. tostring(map))
    end)
end

function _class:asyncWriteArray(filePath, array)
    File:asyncWriteArray(filePath, array, function(codeNumber, path)
        showLabel:text("codeNumber: " .. tostring(codeNumber) .. "\n\ncallBackPath: " .. tostring(path) .. "\n\nPath: " .. filePath .. "\n\narray: " .. tostring(array))
    end)
end

function _class:asyncUnzipFile(sourcePath, targetPath)
    File:asyncUnzipFile(sourcePath, targetPath, function(codeNumber, sourcePath)
        showLabel:text("codeNumber: " .. tostring(codeNumber) .. "\n\ncallBackSourcePath: " .. tostring(sourcePath) .. "\n\nsourcePath: " .. sourcePath .. "\n\ntargetPath: " .. tostring(targetPath))
    end)
end

function _class:syncReadString(filePath)
    local string = File:syncReadString(filePath)
    showLabel:text("Method: syncReadFile\n\n" .. "string: " .. tostring(string) .. "\n\nPath: " .. filePath)
end

function _class:syncWriteFile(filePath, str)
    local codeNumber = File:syncWriteFile(filePath, str)
    showLabel:text("Method: syncWriteFile\n\n" .. "codeNumber: " .. tostring(codeNumber) .. "\n\nPath: " .. filePath .. "\n\nstr: " .. str)
end

function _class:syncWriteMap(filePath, map)
    local codeNumber = File:syncWriteMap(filePath, map)
    showLabel:text("Method: syncWriteMap\n\n" .. "codeNumber: " .. tostring(codeNumber) .. "\n\nPath: " .. filePath .. "\n\nmap: " .. tostring(map))
end

function _class:syncWriteArray(filePath, array)
    local codeNumber = File:syncWriteArray(filePath, array)
    showLabel:text("Method: syncWriteArray\n\n" .. "codeNumber: " .. tostring(codeNumber) .. "\n\nPath: " .. filePath .. "\n\narray: " .. tostring(array))
end

function _class:syncUnzipFile(sourcePath, targetPath)
    local codeNumber = File:syncUnzipFile(sourcePath, targetPath)
    showLabel:text("Method: syncUnzipFile\n\n" .. "codeNumber: " .. tostring(codeNumber) .. "\n\nsourcePath: " .. sourcePath .. "\n\ntargetPath: " .. tostring(targetPath))
end

----1.2.11 新方法 Start

---新方法测试case：
---1. newFile create 未创建 newFile      true
---2. newDir create 未创建 newDir      true
---3. newFile/newDir create 已存在 File/Dir       false
---4. oldFile copy 未创建 newFile       true
---5. oldDir copy 未创建 newDir        true
---6. oldFile/oldDir copy 已存在 File/Dir       false
---7. oldFile move 未创建 newFile       true
---8. oldDir move 未创建 newDir        true
---9. oldFile/oldDir move 已存在 File/Dir       false
---10. delete 已存在 File/Dir       true
---11. delete 未创建 File/Dir       false
---12. 多层级oldFile/oldDir（如：file://a/b） move 已存在 newFile/newDir       false
---13. 多层级oldFile/oldDir（如：file://a/b） copy 已存在 newFile/newDir       false
local basePath = "file://LuaUnitTest/"
local fileA, fileB, dirA, dirB = basePath .. "fileA", basePath .. "fileB", basePath .. "dirA", basePath .. "dirB"
local inerFileA, inerFileB, inerDirA, inerDirB = "inerFileA", "inerFileB", "inerDirB", "inerDirB"
local copyDir, moveDir = "copyDir/", "moveDir/"

function _class:unit_test_start()
    File:asyncDelete(basePath, function(code)
        showLabel:text("Method: asyncDelete\n\n" .. "mkdirs: " .. tostring(code))
        showLabel:text(showLabel:text() .. "\n\n\nexist: " .. tostring(File:exist(fileA)))

        _class:Unit_Create()
    end)
end

function _class:Unit_Create()

    _class:getStorageDir()

    File:asyncCreateFile(fileA, function(code)
        ---1. newFile create 未创建 newFile      true
        showLabel:text(showLabel:text() .. "\n\n\nnewFile create 未创建 newFile: " .. tostring(code == 0 and File:exist(fileA)))

        File:asyncCreateDirs(dirA, function(code)
            ---2. newDir create 未创建 newDir      true
            showLabel:text(showLabel:text() .. "\nnewDir create 未创建 newDir: " .. tostring(code == 0 and File:exist(fileA)))

            ---3. newFile/newDir create 已存在 File/Dir       false
            File:asyncCreateFile(fileA, function(code)
                ---3. newFile create 已存在 File       false
                showLabel:text(showLabel:text() .. "\nnewFile create 已存在 File: " .. tostring(code ~= 0 and File:exist(fileA)))
            end)

            File:asyncCreateFile(dirA, function(code)
                ---3. newFile create 已存在 Dir       false
                showLabel:text(showLabel:text() .. "\nnewFile create 已存在 Dir: " .. tostring(code ~= 0 and File:exist(fileA)))
            end)

            File:asyncCreateDirs(dirA, function(code)
                ---3. newDir create 已存在 Dir      false
                showLabel:text(showLabel:text() .. "\nnewDir create 已存在 Dir: " .. tostring(code ~= 0 and File:exist(fileA)))
            end)

            File:asyncCreateDirs(fileA, function(code)
                ---3. newDir create 已存在 File      false
                showLabel:text(showLabel:text() .. "\nnewDir create 已存在 File: " .. tostring(code ~= 0 and File:exist(fileA)))

                _class:Unit_Copy()
            end)
        end)
    end)

end

function _class:Unit_Copy()

    File:asyncCopyFile(fileA, basePath .. copyDir .. inerFileA, function(code)
        ---4. oldFile copy 未创建 newFile       true
        showLabel:text(showLabel:text() .. "\noldFile copy 未创建 newFile: " .. tostring(code == 0 and File:exist(basePath .. copyDir .. inerFileA)))

        File:asyncCopyFile(dirA, basePath .. copyDir .. inerDirA, function(code)
            ---5. oldDir copy 未创建 newDir        true
            showLabel:text(showLabel:text() .. "\noldDir copy 未创建 newDir: " .. tostring(code == 0 and File:exist(basePath .. copyDir .. inerDirA)))

            -----6. oldFile/oldDir copy 已存在 File/Dir       false
            File:asyncCopyFile(fileA, basePath .. copyDir .. inerFileA, function(code)
                ---6. oldFile copy 已存在 File       false
                showLabel:text(showLabel:text() .. "\noldFile copy 已存在 File: " .. tostring(code ~= 0 and File:exist(basePath .. copyDir .. inerFileA)))
            end)

            File:asyncCopyFile(fileA, basePath .. copyDir .. inerDirA, function(code)
                ---6. oldFile copy 已存在 Dir       false
                showLabel:text(showLabel:text() .. "\noldFile copy 已存在 Dir: " .. tostring(code ~= 0 and File:exist(basePath .. copyDir .. inerDirA)))
            end)

            File:asyncCopyFile(dirA, basePath .. copyDir .. inerDirA, function(code)
                ---6. oldDir copy 已存在 Dir       false
                showLabel:text(showLabel:text() .. "\noldFile copy 已存在 Dir: " .. tostring(code ~= 0 and File:exist(basePath .. copyDir .. inerDirA)))
            end)

            File:asyncCopyFile(dirA, basePath .. copyDir .. inerFileA, function(code)
                ---6. oldDir copy 已存在 File       false
                showLabel:text(showLabel:text() .. "\noldFile copy 已存在 File: " .. tostring(code ~= 0 and File:exist(basePath .. copyDir .. inerFileA)))

                _class:Unit_Move()
            end)

        end)
    end)
end

function _class:Unit_Move()
    ---9. oldFile/oldDir move 已存在 File/Dir       false

    File:asyncMoveFile(fileA, basePath .. moveDir .. inerFileA, function(code)
        ---7. oldFile move 未创建 newFile       true
        showLabel:text(showLabel:text() .. "\noldFile move 未创建 newFile: " .. tostring(code == 0 and not File:exist(fileA) and File:exist(basePath .. moveDir .. inerFileA)))
        File:asyncMoveFile(dirA, basePath .. moveDir .. inerDirA, function(code)
            ---8. oldDir move 未创建 newDir        true
            showLabel:text(showLabel:text() .. "\noldDir move 未创建 newDir: " .. tostring(code == 0 and not File:exist(dirA) and File:exist(basePath .. moveDir .. inerDirA)))

            File:asyncCreateFile(fileB, function(code)
                File:asyncCreateDirs(dirB, function(code)

                    File:asyncMoveFile(fileB, basePath .. moveDir .. inerFileA, function(code)
                        ---9. oldFile move 已存在 File       true
                        showLabel:text(showLabel:text() .. "\noldFile move 已存在 File: " .. tostring(code ~= 0 and File:exist(fileB)))

                        File:asyncMoveFile(dirB, basePath .. moveDir .. inerDirA, function(code)
                            ---9. oldDir move 已存在 Dir        true
                            showLabel:text(showLabel:text() .. "\noldDir move 已存在 Dir: " .. tostring(code ~= 0 and File:exist(dirB)))

                            File:asyncMoveFile(fileB, basePath .. moveDir .. inerDirA, function(code)
                                ---9. oldFile move 已存在 Dir       true
                                showLabel:text(showLabel:text() .. "\noldFile move 已存在 Dir " .. tostring(code ~= 0 and File:exist(fileB)))

                                File:asyncMoveFile(dirB, basePath .. moveDir .. inerFileA, function(code)
                                    ---9. oldDir move 已存在 File        true
                                    showLabel:text(showLabel:text() .. "\noldDir move 已存在 File: " .. tostring(code ~= 0 and File:exist(dirB)))

                                    _class:Unit_Delete()
                                end)
                            end)
                        end)
                    end)
                end)
            end)
        end)
    end)
end

function _class:Unit_Delete()

    File:asyncDelete(basePath .. moveDir .. inerFileA, function(code)
        ---10. delete 已存在 File       true
        showLabel:text(showLabel:text() .. "\ndelete 已存在 iner File: " .. tostring(code == 0 and not File:exist(basePath .. moveDir .. inerFileA)))

        File:asyncDelete(basePath .. moveDir .. inerDirA, function(code)
            ---10. delete 已存在 Dir       true
            showLabel:text(showLabel:text() .. "\ndelete 已存在 iner Dir: " .. tostring(code == 0 and not File:exist(basePath .. moveDir .. inerDirA)))

            File:asyncDelete(basePath .. moveDir, function(code)
                ---10. delete 已存在 Dir       true
                showLabel:text(showLabel:text() .. "\ndelete 已存在 out Dir(无子文件): " .. tostring(code == 0 and not File:exist(basePath .. moveDir)))

                File:asyncDelete(basePath .. moveDir .. inerFileA, function(code)
                    ---11. delete 未创建 File/Dir       false
                    showLabel:text(showLabel:text() .. "\ndelete 未创建 File/Dir(无parent): " .. tostring(code ~= 0 and not File:exist(basePath .. moveDir .. inerFileA)))

                    _class:Unit_Mutil_CopyMove()
                end)
            end)

            File:asyncDelete(basePath .. copyDir, function(code)
                ---10. delete 已存在 Dir       true
                showLabel:text(showLabel:text() .. "\ndelete 已存在 out Dir(有子文件): " .. tostring(code == 0 and not File:exist(basePath .. copyDir)))
            end)

            File:asyncDelete(fileA, function(code)
                ---11. delete 未创建 File/Dir       false
                showLabel:text(showLabel:text() .. "\ndelete 未创建 File/Dir(无parent): " .. tostring(code ~= 0 and not File:exist(fileA)))
            end)
        end)
    end)
end

function _class:Unit_Mutil_CopyMove()

    ---12. 多层级oldFile/oldDir（如：file://a/b） move 已存在 newFile/newDir       false
    File:asyncCreateFile(basePath .. "多级A/" .. inerFileA, function(code)
        File:asyncCreateFile(basePath .. "多级B/" .. inerFileB, function(code)

            File:asyncMoveFile(basePath .. "多级A/" .. inerFileA, basePath .. "多级B/" .. inerFileB, function(code)
                ---多层级oldFile（如：file://a/b） move 已存在 newFile      true
                showLabel:text(showLabel:text() .. "\n多层级file://a/b move 已存在 File: " .. tostring(code ~= 0 and File:exist(basePath .. "多级A/" .. inerFileA)))
            end)

            File:asyncCreateFile(basePath .. "多级A/" .. inerDirA, function(code)
                File:asyncCreateFile(basePath .. "多级B/" .. inerDirB, function(code)

                    File:asyncMoveFile(basePath .. "多级A/" .. inerFileA, basePath .. "多级B/" .. inerDirB, function(code)
                        ---多层级oldFile（如：file://a/b)  move 已存在 newFile      true
                        showLabel:text(showLabel:text() .. "\n多层级file: move 已存在 Dir: " .. tostring(code ~= 0 and File:exist(basePath .. "多级A/" .. inerFileA)))
                    end)

                    File:asyncMoveFile(basePath .. "多级A/" .. inerDirA, basePath .. "多级B/" .. inerDirB, function(code)
                        ---多层级oldFile（如：file://a/b)  move 已存在 newFile      true
                        showLabel:text(showLabel:text() .. "\n多层级dir: move 已存在 dir: " .. tostring(code ~= 0 and File:exist(basePath .. "多级A/" .. inerDirA)))
                    end)
                    File:asyncMoveFile(basePath .. "多级A/" .. inerDirA, basePath .. "多级B/" .. inerFileB, function(code)
                        ---多层级oldFile（如：file://a/b)  move 已存在 newFile      true
                        showLabel:text(showLabel:text() .. "\n多层级dir: move 已存在 File: " .. tostring(code ~= 0 and File:exist(basePath .. "多级A/" .. inerDirA)))
                    end)

                end)
            end)
        end)
    end)

    ---13. 多层级oldFile/oldDir（如：file://a/b  copy 已存在 newFile/newDir       false

    File:asyncCreateFile(basePath .. "多级C/" .. inerFileA, function(code)
        File:asyncCreateFile(basePath .. "多级D/" .. inerFileB, function(code)

            File:asyncCopyFile(basePath .. "多级C/" .. inerFileA, basePath .. "多级D/" .. inerFileB, function(code)
                ---多层级oldFile（如：file://a/b)  move 已存在 newFile      true
                showLabel:text(showLabel:text() .. "\n多层级file: Copy 已存在 File: " .. tostring(code ~= 0 and File:exist(basePath .. "多级C/" .. inerFileA)))
            end)

            File:asyncCreateFile(basePath .. "多级C/" .. inerDirA, function(code)
                File:asyncCreateFile(basePath .. "多级D/" .. inerDirB, function(code)

                    File:asyncCopyFile(basePath .. "多级C/" .. inerFileA, basePath .. "多级D/" .. inerDirB, function(code)
                        ---多层级oldFile（如：file://a/b) move 已存在 newFile      true
                        showLabel:text(showLabel:text() .. "\n多层级file: Copy 已存在 Dir: " .. tostring(code ~= 0 and File:exist(basePath .. "多级C/" .. inerFileA)))
                    end)

                    File:asyncCopyFile(basePath .. "多级C/" .. inerDirA, basePath .. "多级D/" .. inerDirB, function(code)
                        ---多层级oldFile（如：file://a/b)  move 已存在 newFile      true
                        showLabel:text(showLabel:text() .. "\n多层级dir: Copy 已存在 dir: " .. tostring(code ~= 0 and File:exist(basePath .. "多级C/" .. inerDirA)))
                    end)
                    File:asyncCopyFile(basePath .. "多级C/" .. inerDirA, basePath .. "多级D/" .. inerFileB, function(code)
                        ---多层级oldFile（如：file://a/b)  move 已存在 newFile      true
                        showLabel:text(showLabel:text() .. "\n多层级dir: Copy 已存在 File: " .. tostring(code ~= 0 and File:exist(basePath .. "多级C/" .. inerDirA)))
                    end)

                end)
            end)
        end)
    end)
end

function _class:getStorageDir()
    local getStorageDir = File:getStorageDir()
    showLabel:text("Method: getStorageDir\n\n" .. "getStorageDir: " .. tostring(getStorageDir))
end

function _class:getFileList(path, recurisve)
    File:asyncGetFileList(path, recurisve, function(code, fileList)
        local msg = "Method: getStorageDir:\n\n" .. "code: " .. tostring(code) .. "\nfilelist nil?: " .. tostring(fileList == nil) .. "\n"
        if code ~= 0 then
            showLabel:text(msg)
            return
        end
        for i = 1, fileList:size() do
            local filePath = fileList:get(i)
            msg = msg .. tostring(filePath) .. "\n\n"
        end
        msg = msg .. "code: " .. tostring(code)

        showLabel:text(msg)
    end)
end

function _class:getFileInfo(path)
    local fileInfo = File:getFileInfo(path)
    if fileInfo then
        showLabel:text("Method: getFileInfo: \n\nFileSize: " .. tostring(fileInfo:get(FileInfo.FileSize)) .. "\nModify: " .. tostring(fileInfo:get(FileInfo.ModiDate)))
    else
        showLabel:text("Method: getFileInfo: \n\nFileInfo: " .. tostring(fileInfo))
    end
end

function _class:createFile(pathname)
    File:asyncCreateFile(pathname, function(code)
        showLabel:text("Method: asyncCreateFile\n\n" .. "createFile: " .. tostring(code))
    end)
end

function _class:mkdirs(pathname)
    File:asyncCreateDirs(pathname, function(code)
        showLabel:text("Method: asyncCreateDirs\n\n" .. "mkdirs: " .. tostring(code))
    end)
end

function _class:delete(pathname)
    File:asyncDelete(pathname, function(code)
        showLabel:text("Method: asyncDelete\n\n" .. "mkdirs: " .. tostring(code))
    end)
end

function _class:moveFile(fromFile, toFile)
    File:asyncMoveFile(fromFile, toFile, function(code)
        showLabel:text("Method: asyncMoveFile\n\n" .. "moveFile: " .. tostring(code))
    end)
end

function _class:copyFile(fromFile, toFile)
    File:asyncCopyFile(fromFile, toFile, function(code)
        showLabel:text("Method: asyncCopyFile\n\n" .. "copyFile: " .. tostring(code))
    end)
end

----1.2.11 新方法 End


----以下代码不用管，显示UI用的
local topHeight = 0
if System:iOS() then
    topHeight = window:navBarHeight() + window:statusBarHeight()
end

--初始化view
----以下代码不用管，显示UI用的
--local btnInfo = { }
local btnInfo = { "exist", "isDir", "isFile", "asyncReadFile", "asyncReadMapFile", "asyncReadArrayFile",
                  "asyncWriteFile", "asyncWriteMap", "asyncWriteArray", "asyncUnzipFile",
                  "syncReadString", "syncWriteFile", "syncWriteMap", "syncWriteArray", "syncUnzipFile",
                  "syncReadArray", "syncReadMap", "syncReadTextFromAsset", "syncWriteTextToAsset" }

local btnInfo2 = { "单元测试", "getFileList", "getFileInfo", "getStorageDir", "createFile", "mkdirs", "delete", "moveFile", "copyFile" }
local baseMarginTop = 0
if System:iOS() then
    baseMarginTop = 80
end
--初始化view
local Desc = Label():text("请用陌陌客户端扫码测试"):fontSize(19):setWrapContent(true):height(40):textAlign(TextAlign.CENTER):textColor(Color(0, 0, 0, 1)):marginLeft(10):marginTop(90 + baseMarginTop)
contentView:addView(Desc)
local editLabal = EditTextView():text("file://LuaView"):fontSize(19):width(width - 40):textAlign(TextAlign.LEFT):textColor(Color(0, 0, 0, 1)):marginLeft(10):marginTop(125 + baseMarginTop):bgColor(Color(123, 123, 123, 0.3)):singleLine(true)
contentView:addView(editLabal)
local msgEdit = EditTextView():text("momo.lua"):fontSize(19):width(width - 40):textAlign(TextAlign.LEFT):textColor(Color(0, 0, 0, 1)):marginLeft(10):marginTop(155 + baseMarginTop):bgColor(Color(123, 123, 123, 0.3)):singleLine(true)
contentView:addView(msgEdit)
showLabel:width(width - 16):height(height - (16 + (40 + 5) * 3) - 8 - 50 - baseMarginTop):singleLine(false):fontSize(20):textAlign(TextAlign.LEFT):textColor(Color(0, 0, 0, 1)):bgColor(Color(222, 222, 222, 1)):marginTop(16 + (40 + 5) * 4 + baseMarginTop):marginLeft(8):textColor(Color(0, 0, 0, 1))
contentView:addView(showLabel)

window:onClick(function()
    editLabal:dismissKeyboard()
end)

local btnScrollView = ScrollView(true):height(50):width(width):padding(4, 0, 4, 0):scrollEnabled(true):marginTop(baseMarginTop)
contentView:addView(btnScrollView)
local tabsContainer = LinearLayout(LinearType.HORIZONTAL):height(50):width(MeasurementType.WRAP_CONTENT)
btnScrollView:addView(tabsContainer)

local btnScrollView2 = ScrollView(true):height(50):width(width):padding(4, 0, 4, 0):scrollEnabled(true):marginTop(51 + baseMarginTop)
contentView:addView(btnScrollView2)
local tabsContainer2 = LinearLayout(LinearType.HORIZONTAL):height(50):width(MeasurementType.WRAP_CONTENT)
btnScrollView2:addView(tabsContainer2)

local tabs = {}
for i, v in ipairs(btnInfo) do
    local name = v
    local tab = Label():setWrapContent(true):textAlign(TextAlign.CENTER):setMinWidth(80):marginLeft(5):padding(0, 5, 5, 5):height(50):fontSize(14):text(name):bgColor(Color(211, 211, 211, 1)):textColor(Color(0, 0, 0, 1))
    tabsContainer:addView(tab)
    tabs[v] = tab
end

local tabs2 = {}
for i, v in ipairs(btnInfo2) do
    local name = v
    local tab = Label():setWrapContent(true):textAlign(TextAlign.CENTER):setMinWidth(80):marginLeft(5):padding(0, 5, 5, 5):height(50):fontSize(14):text(name):bgColor(Color(211, 211, 211, 1)):textColor(Color(0, 0, 0, 1))
    tabsContainer2:addView(tab)
    tabs2[v] = tab
end

for i, v in pairs(tabs) do
    if i == btnInfo[1] then
        v:onClick(function()
            _class:exist(editLabal:text())
        end)
    elseif i == btnInfo[2] then
        v:onClick(function()
            _class:isDir(editLabal:text())
        end)
    elseif i == btnInfo[3] then
        v:onClick(function()
            _class:isFile(editLabal:text())
        end)
    elseif i == btnInfo[4] then
        v:onClick(function()
            _class:asyncReadFile(editLabal:text())
        end)
    elseif i == btnInfo[5] then
        v:onClick(function()
            _class:asyncReadMapFile(editLabal:text())
        end)
    elseif i == btnInfo[6] then
        v:onClick(function()
            _class:asyncReadArrayFile(editLabal:text())
        end)
    elseif i == btnInfo[7] then
        v:onClick(function()
            --editLabal:text("file://LuaView/momo.lua")
            _class:asyncWriteFile(editLabal:text(), msgEdit:text())
        end)
    elseif i == btnInfo[8] then
        v:onClick(function()
            --editLabal:text("file://LuaView/momo.lua")
            local map = Map()
            map:put("line2", msgEdit:text())
            _class:asyncWriteMap(editLabal:text(), map)
        end)
    elseif i == btnInfo[9] then
        v:onClick(function()
            --editLabal:text("file://LuaView/momo.zip")
            local array = Array()
            array:add(msgEdit:text())
            _class:asyncWriteArray(editLabal:text(), array)
        end)
    elseif i == btnInfo[10] then
        v:onClick(function()
            --editLabal:text("file://LuaView/momo.zip")
            --msgEdit:text("file://LuaView")
            _class:asyncUnzipFile(editLabal:text(), msgEdit:text())
        end)
    elseif i == btnInfo[11] then
        v:onClick(function()
            msgEdit:text("")
            _class:syncReadString(editLabal:text())
        end)
    elseif i == btnInfo[12] then
        v:onClick(function()
            --editLabal:text("file://LuaView/momo.lua")
            _class:syncWriteFile(editLabal:text(), msgEdit:text())
        end)
    elseif i == btnInfo[13] then
        v:onClick(function()
            --editLabal:text("file://LuaView/momo.lua")
            local map = Map()
            map:put("line2", msgEdit:text())
            _class:syncWriteMap(editLabal:text(), map)
        end)

    elseif i == btnInfo[14] then
        v:onClick(function()
            --editLabal:text("file://LuaView/momo.zip")
            local array = Array()
            array:add(msgEdit:text())
            _class:syncWriteArray(editLabal:text(), array)
        end)

    elseif i == btnInfo[15] then
        v:onClick(function()
            --editLabal:text("file://LuaView/momo.zip")
            --msgEdit:text("file://LuaView")
            _class:syncUnzipFile(editLabal:text(), msgEdit:text())
        end)

    elseif i == btnInfo[16] then
        v:onClick(function()
            --msgEdit:text("file://LuaView")
            _class:syncReadArray(msgEdit:text())
        end)

    elseif i == btnInfo[17] then
        v:onClick(function()
            --msgEdit:text("file://LuaView")
            _class:syncReadMap(msgEdit:text())
        end)
    end
end

for i, v in pairs(tabs2) do
    if i == btnInfo2[1] then
        v:onClick(function()
            _class:unit_test_start()
        end)
    elseif i == btnInfo2[2] then
        v:onClick(function()
            _class:getFileList(editLabal:text(), tostring(msgEdit:text()) == "true")
        end)
    elseif i == btnInfo2[3] then
        v:onClick(function()
            _class:getFileInfo(editLabal:text())
        end)
    elseif i == btnInfo2[4] then
        v:onClick(function()
            _class:getStorageDir()
        end)
    elseif i == btnInfo2[5] then
        v:onClick(function()
            _class:createFile(editLabal:text())
        end)
    elseif i == btnInfo2[6] then
        v:onClick(function()
            _class:mkdirs(editLabal:text())
        end)
    elseif i == btnInfo2[7] then
        v:onClick(function()
            _class:delete(editLabal:text())
        end)
    elseif i == btnInfo2[8] then
        v:onClick(function()
            _class:moveFile(editLabal:text(), msgEdit:text())
        end)
    elseif i == btnInfo2[9] then
        v:onClick(function()
            _class:copyFile(editLabal:text(), msgEdit:text())
        end)
    end
end

return _class
