local _class = {}

function _class:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    return o
end

showLabel = Label()

function _class:onCreate(contentView)

    local width = contentView:width()
    local height = contentView:height()

    local btnInfo = { "save", "get" }

    --初始化view
    local Desc = Label():text("动态输入要存 key, 储的值 和 默认值 "):fontSize(19):height(40):textAlign(TextAlign.CENTER):textColor(Color(0, 0, 0, 1)):marginLeft(10):marginTop(50)
    contentView:addView(Desc)

    local keyLabel = EditTextView():text("momo"):fontSize(19):width(width - 20):textAlign(TextAlign.LEFT):textColor(Color(0, 0, 0, 1)):marginLeft(10):marginTop(90)
    contentView:addView(keyLabel)

    local editLabal = EditTextView():text("targetValue"):fontSize(19):width(width - 20):textAlign(TextAlign.LEFT):textColor(Color(0, 0, 0, 1)):marginLeft(10):marginTop(110)
    contentView:addView(editLabal)
    local msgEdit = EditTextView():text("defaultValue"):fontSize(19):width(width - 20):textAlign(TextAlign.LEFT):textColor(Color(0, 0, 0, 1)):marginLeft(10):marginTop(140)
    contentView:addView(msgEdit)
    contentView:addView(initShowLabel(showLabel, width, height * 0.6))

    local btnScrollView = ScrollView(true)
    btnScrollView:height(50)
    btnScrollView:width(width)
    btnScrollView:marginTop(200)
    btnScrollView:marginLeft(200)
    contentView:addView(btnScrollView)
    local tabsContainer = LinearLayout(LinearType.HORIZONTAL):height(50):setWrapContent(true)
    btnScrollView:addView(tabsContainer)

    local tabs = {}
    for i, v in ipairs(btnInfo) do
        name = v
        local tab = Label():setWrapContent(true):textAlign(TextAlign.CENTER):setMinWidth(80):marginLeft(5):padding(0, 5, 5, 5):height(50):fontSize(14):text(name):bgColor(Color(211, 211, 211, 1)):textColor(Color(0, 0, 0, 1))
        tabsContainer:addView(tab)
        tabs[v] = tab
    end

    for i, v in pairs(tabs) do
        if i == btnInfo[1] then
            v:onClick(function()
                _class:save(tostring(keyLabel:text()), editLabal:text())
            end)
        elseif i == btnInfo[2] then
            v:onClick(function()
                 _class:get(tostring(keyLabel:text()), msgEdit:text())
            end)
        end
    end

end

function _class:save(key, value)
    PreferenceUtils:save(key, value)
    showLabel:text("Save\n\nkey: " .. key .. "\n\nvalue: " .. value)
end

function _class:get(key, default)
    local value = PreferenceUtils:get(key, default)
    showLabel:text("Get\n\nkey: " .. key .. "\n\nvalue: " .. value .. "\n\ndefault: " .. default)
end


function initShowLabel(showLabel, width, height)
    showLabel:width(width - 16):height(height - (16 + (40 + 5) * 3) - 8):lines(0):fontSize(20):textAlign(TextAlign.LEFT):textColor(Color(0, 0, 0, 1)):bgColor(Color(222, 222, 222, 1)):marginTop(250):marginLeft(8):textColor(Color(0, 0, 0, 1))
    return showLabel
end

_class:onCreate(window)
