
HomeCommonCell = require('MMLuaKitGallery.Home.HomeCommonCell')


local topHeight = window:statusBarHeight() + window:navBarHeight()

local DataSource = {
    sections = {
        {
            items = {
                {
                    type = 'type1',
                    text = 'type ----- 1 \n section----- 1 \n item ----- 1',
                    choosed = false
                },
                {
                    type = 'type2',
                    text = 'type ----- 2 \n section----- 1 \n item ----- 2',
                    choosed = false
                }
            }
        },
        {
            items = {
                {
                    type = 'type1',
                    text = 'type ----- 1 \n section----- 2 \n item ----- 1',
                    choosed = false
                }
            }
        },
    }
}
Color_Clear = Color(255, 255, 255, 0)
Color_White = Color(255, 255, 255, 1)
local W = System:screenSize():width()
local H = System:screenSize():height()
local choosedSection = 0
local choosedItem = 0
mainView = TableView(false, false)
        --:width(W):height(H)
:width(MeasurementType.WRAP_CONTENT)
:height(MeasurementType.WRAP_CONTENT)
        :marginTop(topHeight + 80)
        :bgColor(Color(255, 255, 255, 1))
mainView:showScrollIndicator(true)
window:addView(mainView)
adapter = TableViewAdapter()

--adapter:showPressed(true)
--adapter:pressedColor(Color(200, 120, 120, 1))

adapter:sectionCount(function()
    return #DataSource.sections
end)

adapter:rowCount(function(section)
    return #DataSource.sections[section].items
end)

adapter:reuseId(function(section, row)
    local section = DataSource.sections[section]
    local item = section.items[row]
    return item.type
end)

adapter:initCellByReuseId('type1', function(cell)

    cell.contentView:addView(HomeCommonCell:new():rootView())
end)

adapter:initCellByReuseId('type2', function(cell)
    --cell.contentView:bgColor(Color(0, 233, 155, 0.6))
    cell.layout = View():width(MeasurementType.MATCH_PARENT)
                        :height(MeasurementType.MATCH_PARENT)
    cell.textLabel = Label():setGravity(Gravity.CENTER):width(MeasurementType.WRAP_CONTENT):height(70):lines(0)
                            :textAlign(TextAlign.CENTER)
                            :bgColor(Color(255, 255, 255, 1))
    cell.layout:addView(cell.textLabel)
    cell.contentView:addView(cell.layout)
end)

adapter:fillCellDataByReuseId('type1', function(cell, section, row)
    local section = DataSource.sections[section]
    local item = section.items[row]
    cell.textLabel:text(item.text)
    if item.choosed then
        cell.layout:bgColor(Color_Clear):setGradientColor(Color(210,82,136,0.9), Color(170,46,157,0.9), false);
        --cell.layout:setGradientColor(Color(255, 0, 0, 0.5), Color(255, 255, 0, 0.5), false)
    else
        cell.layout:setGradientColor(Color_Clear, Color_Clear, false):bgColor(Color(147,47,135,0.5))
    end
end)

adapter:fillCellDataByReuseId('type2', function(cell, section, row)
    local section = DataSource.sections[section]
    local item = section.items[row]
    cell.textLabel:text(item.text)
    if item.choosed then
        cell.layout:bgColor(Color_Clear):setGradientColor(Color(210,82,136,0.9), Color(170,46,157,0.9), false);
        --cell.layout:setGradientColor(Color(255, 0, 0, 0.5), Color(255, 255, 0, 0.5), false)
    else
        cell.layout:setGradientColor(Color_Clear, Color_Clear, false):bgColor(Color(147,47,135,0.5))
    end

end)

adapter:heightForCell(function(section, row)
    return 300;
end)

adapter:selectedRow(function(cell, section, row)
    textSelected = "cell selected " .. "section: " .. section .. " row: " .. row
    --cell.textLabel:text(textSelected)
    print("cell selected " .. "section: " .. section .. " row: " .. row)
    if choosedItem > 0 and choosedSection > 0 then
        DataSource.sections[choosedSection].items[choosedItem].choosed = false
        mainView:reloadAtRow(choosedItem,choosedSection,false)
    end
    choosedSection = section
    choosedItem = row
    DataSource.sections[choosedSection].items[choosedItem].choosed = true
    mainView:reloadAtRow(choosedItem,choosedSection,false)
    --mainView:reloadData()
end)

mainView:adapter(adapter)
