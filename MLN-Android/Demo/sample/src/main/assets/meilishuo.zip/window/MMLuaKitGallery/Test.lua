local TabBarView = {}

function TabBarView:new(o)
    o = o or {}			-- o不为nil，则o = o, 否则o = {}，此处o相当于上段代码中的per
    setmetatable(o, self)	-- 将Person设为表o的原表
    self.__index = self		-- 将Person的__index指向它本身，使得上一步相当于setmetatable(o, {__index = self})

    return o
end

function TabBarView:setupClickCallback(callback)
    self.clickCallback = callback
end

function TabBarView:createView()
    print("Creating...")

    local windowHeight = window:height()
    local windowWidth = window:width()


    --tabView = View()
    --tabView:bgColor(Color(25,255,255,1)):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT):marginTop(0)

    --Tab选项卡
    local tabToolBarHeight = 100
    self.tabToolBar = LinearLayout(LinearType.HORIZONTAL)
    self.tabToolBar:bgColor(Color(255,165,41,1)):width(MeasurementType.MATCH_PARENT):height(tabToolBarHeight):marginBottom(0):setGravity(Gravity.BOTTOM)
    --tabView:addView(tabToolBar)


    --TabBarButtonItem

    local barButtonItemHeight = 50
    local barButtonItemWidth = 50
    local barButtonItemSpacing = (windowWidth - barButtonItemWidth * 5) / 6

    homeBarButtonItem = ImageButton():width(barButtonItemWidth):height(barButtonItemHeight):cornerRadius(35):marginLeft(barButtonItemSpacing):marginRight(0):bgColor(Color(250,82,239,1)):setGravity(Gravity.CENTER_VERTICAL)
    homeBarButtonItem:onClick(function()
    --print('homeBarButtonItem')
        if self.clickCallback ~= nil then
            self.clickCallback(0)
        end
    end)
    homeBarButtonItem:setImage("logo")
    tabToolBar:addView(homeBarButtonItem)

    discoverBarButtonItem = ImageButton():width(barButtonItemWidth):height(barButtonItemHeight):cornerRadius(35):marginLeft(barButtonItemSpacing):marginRight(0):bgColor(Color(254,223,235,1)):setGravity(Gravity.CENTER_VERTICAL)
    discoverBarButtonItem:onClick(function()
    print('discoverBarButtonItem')

    end)
    discoverBarButtonItem:setImage("logo")
    tabToolBar:addView(discoverBarButtonItem)

    plusBarButtonItem = ImageButton():width(barButtonItemWidth):height(barButtonItemHeight):cornerRadius(35):marginLeft(barButtonItemSpacing):marginRight(0):bgColor(Color(245,150,170,1)):setGravity(Gravity.CENTER_VERTICAL)
    plusBarButtonItem:onClick(function()
    print('plusBarButtonItem')

    end)
    plusBarButtonItem:setImage("logo")
    tabToolBar:addView(plusBarButtonItem)

    messageBarButtonItem = ImageButton():width(barButtonItemWidth):height(barButtonItemHeight):cornerRadius(35):marginLeft(barButtonItemSpacing):marginRight(0):bgColor(Color(208,90,110,1)):setGravity(Gravity.CENTER_VERTICAL)
    messageBarButtonItem:onClick(function()
    print('messageBarButtonItem')

    end)
    messageBarButtonItem:setImage("logo")
    tabToolBar:addView(messageBarButtonItem)

    mineBarButtonItem = ImageButton():width(barButtonItemWidth):height(barButtonItemHeight):cornerRadius(35):marginLeft(barButtonItemSpacing):marginRight(barButtonItemSpacing):bgColor(Color(245,92,47,1)):setGravity(Gravity.CENTER_VERTICAL)
    mineBarButtonItem:onClick(function()
    print('mineBarButtonItem')

    end)
    mineBarButtonItem:setImage("logo")
    tabToolBar:addView(mineBarButtonItem)

    --return self.tabToolBar
end


return  TabBarView




tabBarViewController = TabBarView:new()
local homeView = tabBarViewController:createView()
window:addView(homeView)



