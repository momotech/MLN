


local windowHeight = window:height()
local windowWidth = window:width()


tabView = View()
tabView:bgColor(Color(25,255,255,1)):width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT):marginTop(0)
window:addView(tabView)

--Tab选项卡
local tabToolBarHeight = 100
tabToolBar = LinearLayout(LinearType.HORIZONTAL)
tabToolBar:bgColor(Color(255,165,41,1)):width(MeasurementType.MATCH_PARENT):height(tabToolBarHeight):marginBottom(0):setGravity(Gravity.BOTTOM)
tabView:addView(tabToolBar)


--TabBarButtonItem

local barButtonItemHeight = 50
local barButtonItemWidth = 50
local barButtonItemSpacing = (windowWidth - barButtonItemWidth * 5) / 6

homeBarButtonItem = ImageButton():width(barButtonItemWidth):height(barButtonItemHeight):cornerRadius(35):marginLeft(barButtonItemSpacing):marginRight(0):bgColor(Color(250,82,239,1)):setGravity(Gravity.CENTER_VERTICAL):contentMode(ContentMode.SCALE_ASPECT_FIT)
homeBarButtonItem:onClick(function()
print('homeBarButtonItem')
end)
homeBarButtonItem:setImage("logo")
tabToolBar:addView(homeBarButtonItem)

discoverBarButtonItem = ImageButton():width(barButtonItemWidth):height(barButtonItemHeight):cornerRadius(35):marginLeft(barButtonItemSpacing):marginRight(0):bgColor(Color(254,223,235,1)):setGravity(Gravity.CENTER_VERTICAL)
discoverBarButtonItem:onClick(function()
print('discoverBarButtonItem')

end)
discoverBarButtonItem:setImage("logo")
tabToolBar:addView(discoverBarButtonItem)

plusBarButtonItem = ImageButton():width(barButtonItemWidth):height(barButtonItemHeight):cornerRadius(35):marginLeft(barButtonItemSpacing):marginRight(0):bgColor(Color(245,150,170,1)):setGravity(Gravity.CENTER_VERTICAL)
plusBarButtonItem:onClick(function()
print('plusBarButtonItem')

end)
plusBarButtonItem:setImage("logo")
tabToolBar:addView(plusBarButtonItem)

messageBarButtonItem = ImageButton():width(barButtonItemWidth):height(barButtonItemHeight):cornerRadius(35):marginLeft(barButtonItemSpacing):marginRight(0):bgColor(Color(208,90,110,1)):setGravity(Gravity.CENTER_VERTICAL)
messageBarButtonItem:onClick(function()
print('messageBarButtonItem')

end)
messageBarButtonItem:setImage("logo")
tabToolBar:addView(messageBarButtonItem)

mineBarButtonItem = ImageButton():width(barButtonItemWidth):height(barButtonItemHeight):cornerRadius(35):marginLeft(barButtonItemSpacing):marginRight(barButtonItemSpacing):bgColor(Color(245,92,47,1)):setGravity(Gravity.CENTER_VERTICAL)
mineBarButtonItem:onClick(function()
print('mineBarButtonItem')

end)
mineBarButtonItem:setImage("logo")
tabToolBar:addView(mineBarButtonItem)
