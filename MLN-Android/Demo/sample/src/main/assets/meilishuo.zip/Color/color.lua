local screen_w = window:width()
local screen_h = window:height()
local TopBarHeight = System:stateBarHeight() + System:navBarHeight()

local horizonScrollview = ScrollView(false, true)
horizonScrollview:width(MeasurementType.MATCH_PARENT)
horizonScrollview:height(200):marginTop(TopBarHeight)
window:addView(horizonScrollview)

--测试多个参数
--Color(123,123,123,1,123)
--Color(123,123)

-- 构造方法 创建Color 对象
testCaseLabel = Label():width(MeasurementType.WRAP_CONTENT):height(40):marginLeft(0):marginTop(20):lines(0):textAlign(TextAlign.CENTER)
testCaseLabel:bgColor(Color(127, 255, 170, 1))
testCaseLabel:text('背景颜色值  Color(127,255,170,1) ')


-- 点击 clear() 清除背景色
color2 = Color():setColor("#F3F3F3")
testCaseLabel2 = Label():width(MeasurementType.WRAP_CONTENT):height(40):marginLeft(0):marginTop(20):lines(0):textAlign(TextAlign.CENTER)
testCaseLabel2:bgColor(color2)
testCaseLabel2:text('点击清楚背景颜色   Color():setColor("#F3F3F3") ')

testCaseLabel2:onClick(function()
    color2:clear()
    testCaseLabel2:bgColor(color2)
end)

--  通过setRGBA（） 设置的背景色
color3 = Color():setRGBA(200, 180, 250, 1)
testCaseLabel3 = Label():width(MeasurementType.WRAP_CONTENT):height(40):marginLeft(0):marginTop(20):lines(0):textAlign(TextAlign.CENTER)
testCaseLabel3:bgColor(color3)
testCaseLabel3:text(' 通过setRGBA（） 来设置的背景色  Color():setRGBA(200,180,250,1) ')


-- 通过setColor('rgba()')  参数为字符串， 设置的背景色
color4 = Color():setColor('rgba(200,120,120,1)')
testCaseLabel4 = Label():width(MeasurementType.WRAP_CONTENT):height(40):marginLeft(0):marginTop(20):lines(0):textAlign(TextAlign.CENTER)
testCaseLabel4:bgColor(color4)
testCaseLabel4:text(' 通过setColor(\'rgba()  参数为字符串 来设置的背景色  ')

-- setAColor('rgba()')  参数为字符串， 设置的背景色
color5 = Color():setAColor('#ffaabbff')
testCaseLabel5 = Label():width(MeasurementType.WRAP_CONTENT):height(40):marginLeft(0):marginTop(20):lines(0):textAlign(TextAlign.CENTER)
testCaseLabel5:bgColor(color5)
testCaseLabel5:text(' setAColor(\'#ffaabbff\')   参数为字符串,字符串内容为颜色值， 来设置的背景色  ')


-- hex 方法 设置的背景色
color6 = Color():hex(0xff00ff):alpha(1)
testCaseLabel6 = Label():width(MeasurementType.WRAP_CONTENT):height(40):marginLeft(0):marginTop(20):lines(0):textAlign(TextAlign.CENTER)
testCaseLabel6:bgColor(color6)
testCaseLabel6:text(' hex(0xff00ff)  设置或获取除alpha通道外的颜色值 16进制  ')

-- setHexA方法 设置的背景色
color7 = Color():setHexA(0xE8E8E8, 1)
testCaseLabel7 = Label():width(MeasurementType.WRAP_CONTENT):height(40):marginLeft(0):marginTop(20):lines(0):textAlign(TextAlign.CENTER)
testCaseLabel7:bgColor(color7)
testCaseLabel7:text(' setHexA方法 颜色值 ')



-- red()方法 设置的背景色
color8 = Color():red(255)
testCaseLabel8 = Label():width(MeasurementType.WRAP_CONTENT):height(40):marginLeft(0):marginTop(20):lines(0):textAlign(TextAlign.CENTER)
testCaseLabel8:bgColor(color8)
testCaseLabel8:text(' red(255)方法 设置的背景色 ')

-- green()方法 设置的背景色
color9 = Color():green(50)
testCaseLabel9 = Label():width(MeasurementType.WRAP_CONTENT):height(40):marginLeft(0):marginTop(20):lines(0):textAlign(TextAlign.CENTER)
testCaseLabel9:bgColor(color9)
testCaseLabel9:text(' green(50)方法 设置的背景色 ')

-- blue()方法 设置的背景色
color10 = Color():blue(150)
testCaseLabel10 = Label():width(MeasurementType.WRAP_CONTENT):height(40):marginLeft(0):marginTop(20):lines(0):textAlign(TextAlign.CENTER)
testCaseLabel10:bgColor(color10)
testCaseLabel10:text(' blue(150)方法 设置的背景色 ')

color11 = Color(205, 105, 105)
testCaseLabel11 = Label():width(MeasurementType.WRAP_CONTENT):height(40):marginLeft(0):marginTop(20):lines(0):textAlign(TextAlign.CENTER)
testCaseLabel11:bgColor(color11)
testCaseLabel11:text('Color(205,105,105)')

color12 = Color(205, 105, 105, 0.5)
testCaseLabel12 = Label():width(MeasurementType.WRAP_CONTENT):height(40):marginLeft(0):marginTop(20):lines(0):textAlign(TextAlign.CENTER)
testCaseLabel12:bgColor(color12)
testCaseLabel12:text('Color(205,105,105,0.5)')

horizonScrollview:addView(testCaseLabel)
horizonScrollview:addView(testCaseLabel2)
horizonScrollview:addView(testCaseLabel3)
horizonScrollview:addView(testCaseLabel4)
horizonScrollview:addView(testCaseLabel5)
horizonScrollview:addView(testCaseLabel6)
horizonScrollview:addView(testCaseLabel7)
horizonScrollview:addView(testCaseLabel8)
horizonScrollview:addView(testCaseLabel9)
horizonScrollview:addView(testCaseLabel10)
horizonScrollview:addView(testCaseLabel11)
horizonScrollview:addView(testCaseLabel12)

--- ActionView
local ActionView = require("CollectionView.ActionViews")
local actionView = ActionView:new()
actionView.contentView:marginTop(TopBarHeight + 220):width(screen_w)
window:addView(actionView.contentView)
TopBarHeight = TopBarHeight + actionView.contentView:height()

color13 = Color(255, 255, 255, 0.5)
testCaseLabel13 = Label():width(MeasurementType.WRAP_CONTENT):height(40):marginLeft(0):marginTop(actionView.contentView:height() + actionView.contentView:marginTop() + 10):lines(0):textAlign(TextAlign.CENTER)
testCaseLabel13:bgColor(color13)
testCaseLabel13:text('动态输入结果显示在这里')
window:addView(testCaseLabel13)

colorLabel = Label():width(MeasurementType.WRAP_CONTENT):height(40):marginLeft(0):marginTop(actionView.contentView:height() + actionView.contentView:marginTop() + 60):lines(0):textAlign(TextAlign.CENTER)
window:addView(colorLabel)
actionView:setupEdtItemInTime('Color ( red,green,blue,alpha)', function(editTextView)
    local indexPathStr = editTextView:text()
    local array = actionView:split(indexPathStr, ',')

    print(tonumber(array[1]), ' type = ', type(tonumber(array[1])))

    color13 = Color(tonumber(array[1]), tonumber(array[2]), tonumber(array[3]), tonumber(array[4]))
    testCaseLabel13:bgColor(color13)
    colorLabel:text('对应颜色值-->'
            .. color13:red() .. "," .. color13:green() .. "," .. color13:blue() .. "," .. color13:alpha())

end)

actionView:setupEdtItemInTime('Color():setRGBA(red,green,blue,alpha)', function(editTextView)
    local indexPathStr = editTextView:text()
    local array = actionView:split(indexPathStr, ',')

    color13 = Color():setRGBA(tonumber(array[1]), tonumber(array[2]), tonumber(array[3]), tonumber(array[4]))
    testCaseLabel13:bgColor(color13)
    colorLabel:text('对应颜色值-->'
            .. color13:red() .. "," .. color13:green() .. "," .. color13:blue() .. "," .. color13:alpha())

end)

actionView:setupEdtItemInTime('Color():red( value )', function(editTextView)
    local indexPathStr = editTextView:text()

    color13 = Color():red(tonumber(indexPathStr))
    testCaseLabel13:bgColor(color13)
    colorLabel:text('对应颜色值-->'
            .. color13:red() .. "," .. color13:green() .. "," .. color13:blue() .. "," .. color13:alpha())

end)

actionView:setupEdtItemInTime('Color():green( value )', function(editTextView)
    local indexPathStr = editTextView:text()

    color13 = Color():green(tonumber(indexPathStr))
    testCaseLabel13:bgColor(color13)
    colorLabel:text('对应颜色值-->'
            .. color13:red() .. "," .. color13:green() .. "," .. color13:blue() .. "," .. color13:alpha())

end)

actionView:setupEdtItemInTime('Color():blue( value )', function(editTextView)
    local indexPathStr = editTextView:text()

    color13 = Color():blue(tonumber(indexPathStr))
    testCaseLabel13:bgColor(color13)
    colorLabel:text('对应颜色值-->'
            .. color13:red() .. "," .. color13:green() .. "," .. color13:blue() .. "," .. color13:alpha())

end)
if window:getExtra() ~= nil then
    print("key=" .. tostring(window:getExtra():get("key")))
else
    print("window:getExtra() = nil")
end

print("--->1111")
print("--->2222")
print("--->3333")
