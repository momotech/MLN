local DataSource = {
    sections = {
        {
            items = {
                {
                    type = 'type1',
                    text = 'type ----- 1 \n section----- 1 \n item ----- 1'
                },
                {
                    type = 'type2',
                    text = 'type ----- 2 \n section----- 1 \n item ----- 2'
                },
                {
                    type = 'type1',
                    text = 'type ----- 1 \n section----- 1 \n item ----- 3'
                },
                {
                    type = 'type2',
                    text = 'type ----- 2 \n section----- 1 \n item ----- 4'
                },
                {
                    type = 'type1',
                    text = 'type ----- 1 \n section----- 1 \n item ----- 5'
                },
                {
                    type = 'type2',
                    text = 'type ----- 2 \n section----- 1 \n item ----- 6'
                },
                {
                    type = 'type1',
                    text = 'type ----- 1 \n section----- 1 \n item ----- 7'
                },
                {
                    type = 'type2',
                    text = 'type ----- 2 \n section----- 1 \n item ----- 8'
                },
                {
                    type = 'type1',
                    text = 'type ----- 1 \n section----- 1 \n item ----- 9'
                },
            }
        },
        {
            items = {
                {
                    type = 'type1',
                    text = 'type ----- 1 \n section----- 2 \n item ----- 1'
                },
                {
                    type = 'type2',
                    text = 'type ----- 2 \n section----- 2 \n item ----- 2'
                },
                {
                    type = 'type1',
                    text = 'type ----- 1 \n section----- 2 \n item ----- 3'
                },
                {
                    type = 'type2',
                    text = 'type ----- 2 \n section----- 2 \n item ----- 4'
                },
                {
                    type = 'type1',
                    text = 'type ----- 1 \n section----- 2 \n item ----- 5'
                },
                {
                    type = 'type2',
                    text = 'type ----- 2 \n section----- 2 \n item ----- 6'
                },
                {
                    type = 'type1',
                    text = 'type ----- 1 \n section----- 2 \n item ----- 7'
                },
                {
                    type = 'type2',
                    text = 'type ----- 2 \n section----- 2 \n item ----- 8'
                },
                {
                    type = 'type1',
                    text = 'type ----- 1 \n section----- 2 \n item ----- 9'
                },
            }
        },
    }
}

local screen_w = window:width()
local screen_h = window:height()
local TopBarHeight = System:stateBarHeight() + System:navBarHeight()

--- ActionView
local ActionView = require("CollectionView.ActionViews")
local actionView = ActionView:new()
actionView.contentView:marginTop(TopBarHeight):width(screen_w)
window:addView(actionView.contentView)
TopBarHeight = TopBarHeight + actionView.contentView:height()


local horizonScrollview = ScrollView(true, true)
horizonScrollview:width(MeasurementType.MATCH_PARENT)
horizonScrollview:height(60):marginTop(TopBarHeight)
window:addView(horizonScrollview)
TopBarHeight = TopBarHeight + horizonScrollview:height()


mainView = TableView(true, true):frame(Rect(0, TopBarHeight, screen_w, screen_h - TopBarHeight))
mainView:showScrollIndicator(true)
window:addView(mainView)

mainView:setRefreshingCallback(function()

    System:setTimeOut(function()

        mainView:stopRefreshing()
            mainView:resetLoading()
            mainView:reloadData()
            Toast('刷新数据')

    end, 1.0)
end)

mainView:setLoadingCallback(function()
    System:setTimeOut(function()
        value = {
            type = 'type1',
            text = '上拉加载更多添加的视图'
        }

        local section = DataSource.sections[1]
        local count = #section.items

        table.insert(DataSource.sections[2].items, count + 1, value)
        mainView:insertRow(count + 1, 2, false)
        mainView:stopLoading()
        mainView:stopRefreshing()
        mainView:noMoreData()
    end, 1.0)
end)

mainView:setScrollBeginCallback(function(x,y)
     print('开始滚动的回调 x = '..tostring(x)..'   y ='..tostring(y))
end)

mainView:setScrollingCallback(function(x,y)
    print('滚动中的回调 x = '..tostring(x)..'   y ='..tostring(y))
end)

mainView:setScrollEndCallback(function(x,y)
    print('停止滚动的回调 x = '..tostring(x)..'   y ='..tostring(y))
end)


mainView:setEndDraggingCallback(function()
        -- print('设置结束drag回调')
end)

mainView:setStartDeceleratingCallback(function(x,y)
     print('获取当前滚动offset  x ='..tostring(x)..'  y='..tostring(y))
end)

adapter = TableViewAutoFitAdapter()

adapter:showPressed(true)
adapter:pressedColor(Color(200, 120, 120, 1))

adapter:sectionCount(function()
    return #DataSource.sections
end)

adapter:rowCount(function(section)
    return #DataSource.sections[section].items
end)

--[[
adapter:initCell(function(cell)
    cell.contentView:bgColor(Color(0,191,255,1))
    cell.textLabel = Label():setGravity(Gravity.CENTER):width(MeasurementType.WRAP_CONTENT):height(60):lines(0):textAlign(TextAlign.CENTER)
    cell.contentView:addView(cell.textLabel)
end)

adapter:fillCellData(function(cell, section, row)
    local section = DataSource.sections[section]
    local item = section.items[row]
    cell.textLabel:text(item.text)
end)
--]]

adapter:reuseId(function(section, row)
    local section = DataSource.sections[section]
    local item = section.items[row]
    return item.type
end)

adapter:initCellByReuseId('type1', function(cell)
    cell.contentView:bgColor(Color(0, 191, 255, 1))
    cell.textLabel = Label():setGravity(Gravity.CENTER):width(MeasurementType.WRAP_CONTENT):height(60):lines(0):textAlign(TextAlign.CENTER):marginTop(20):marginBottom(20)
    cell.contentView:addView(cell.textLabel)
end)

adapter:initCellByReuseId('type2', function(cell)
    cell.contentView:bgColor(Color(0, 233, 155, 1))
    cell.textLabel = Label():setGravity(Gravity.CENTER):width(MeasurementType.WRAP_CONTENT):height(60):lines(0):textAlign(TextAlign.CENTER):marginTop(20):marginBottom(20)
    cell.contentView:addView(cell.textLabel)
end)

adapter:fillCellDataByReuseId('type1', function(cell, section, row)
    local section = DataSource.sections[section]
    local item = section.items[row]
    cell.textLabel:text(item.text)
end)

adapter:fillCellDataByReuseId('type2', function(cell, section, row)
    local section = DataSource.sections[section]
    local item = section.items[row]
    cell.textLabel:text(item.text)
end)

adapter:longPressRow(function(cell,section,row)
    Toast('长按 第 '..tostring(row)..' 行',3)
end)

adapter:heightForCell(function(section,row)
   return 60;
end)

adapter:cellWillAppearByReuseId('type1', function(cell, section, row)
    print("--------- cell type1 appear ", "section: " .. section .. " row: " .. row)
end)

adapter:cellWillAppearByReuseId('type2', function(cell, section, row)
    print("--------- cell type2 appear ", "section: " .. section .. " row: " .. row)
end)

adapter:cellDidDisappearByReuseId('type1', function(cell, section, row)
    print("--------- cell type2 disappear ", "section: " .. section .. " row: " .. row)
end)

adapter:cellDidDisappearByReuseId('type2', function(cell, section, row)
    print("--------- cell type2 disappear ", "section: " .. section .. " row: " .. row)
end)

adapter:selectedRow(function(cell, section, row)
    textSelected = "cell selected " .. "section: " .. section .. " row: " .. row
    cell.textLabel:text(textSelected)
end)


actionView:setupEdtItemInTime('插入单条->insertCellAtRow(row, section)', function (editTextView)
    local value =  {
        type = 'type1',
        text = 'section----- 1 \n row ----- -1'
    }
    local text = editTextView:text()
    local array = actionView:split(text, ',')
    table.insert(DataSource.sections[1].items, tonumber(array[1]), value)
    mainView:insertCellAtRow(tonumber(array[1]), tonumber(array[2]))

    local tbl = {"insertCellAtRow(", tostring(array[1]), ',', tostring(array[2]), ')'}
    actionView:setTestContent(table.concat(tbl))
    mainView:scrollToTop(true)
end)

actionView:setupEdtItemInTime('删除单条->deleteCellAtRow(row, section)', function (editTextView)
    local text = editTextView:text()
    local array = actionView:split(text, ',')
    table.remove(DataSource.sections[tonumber(array[2])].items, tonumber(array[1]))
    mainView:deleteCellAtRow(tonumber(array[1]), tonumber(array[2]))
end)

actionView:setupEdtItemInTime('插入N条->insertCellsAtSection(N, section, startRow, endRow)', function (editTextView)
    local text = editTextView:text()
    local array = actionView:split(text, ',')

    local count = tonumber(array[1])
    local section = tonumber(array[2])
    local startRow = tonumber(array[3])
    local endRow = tonumber(array[4])

    for i = startRow, endRow, 1 do
        local value = {
            type = 'type1',
            text = tostring(i).."hello world, hello world",
        }

        table.insert(DataSource.sections[section].items, startRow, value)
    end

    mainView:insertCellsAtSection(section, startRow, endRow)
end)


actionView:setupEdtItemInTime('删除N条->deleteCellsAtSection(N, section, startRow, endRow)', function (editTextView)
    local text = editTextView:text()
    local array = actionView:split(text, ',')

    local count = tonumber(array[1])
    local section = tonumber(array[2])
    local startRow = tonumber(array[3])
    local endRow = tonumber(array[4])

    for i = startRow, endRow, 1 do
        table.remove(DataSource.sections[section].items, startRow)
    end

    mainView:deleteCellsAtSection(section, startRow, endRow)
end)

actionView:setupEdtItemInTime('插入单条->insertRow(row, section, anim)', function (editTextView)
    local value =  {
        type = 'type1',
        text = 'section----- 1 \n row ----- -1'
    }
    local text = editTextView:text()
    local array = actionView:split(text, ',')
    table.insert(DataSource.sections[1].items, tonumber(array[1]), value)
    mainView:insertRow(tonumber(array[1]), tonumber(array[2]), tonumber(array[3]) == 1)

    local tbl = {"insertCellAtRow(", tostring(array[1]), ',', tostring(array[2]), ',', tostring(array[3]), ')'}
    actionView:setTestContent(table.concat(tbl))
end)

actionView:setupEdtItemInTime('删除单条->deleteRow(row, section，anim)', function (editTextView)
    local text = editTextView:text()
    local array = actionView:split(text, ',')
    table.remove(DataSource.sections[tonumber(array[2])].items, tonumber(array[1]))
    mainView:deleteRow(tonumber(array[1]), tonumber(array[2]), tonumber(array[3]) == 1)
end)

actionView:setupEdtItemInTime('插入N条->insertRowsAtSection(N, section, startRow, endRow, anim)', function (editTextView)
    local text = editTextView:text()
    local array = actionView:split(text, ',')

    local count = tonumber(array[1])
    local section = tonumber(array[2])
    local startRow = tonumber(array[3])
    local endRow = tonumber(array[4])
    local anim = tonumber(array[5]) == 1

    for i = startRow, endRow, 1 do
        local value = {
            type = 'type1',
            text = tostring(i).."hello world, hello world",
        }

        table.insert(DataSource.sections[section].items, startRow, value)
    end
    mainView:insertRowsAtSection(section, startRow, endRow, anim)
end)


actionView:setupEdtItemInTime('删除N条->deleteRowsAtSection(N, section, startRow, endRow, anim)', function (editTextView)
    local text = editTextView:text()
    local array = actionView:split(text, ',')

    local count = tonumber(array[1])
    local section = tonumber(array[2])
    local startRow = tonumber(array[3])
    local endRow = tonumber(array[4])
    local anim = tonumber(array[5]) == 1

    for i = startRow, endRow, 1 do
        table.remove(DataSource.sections[section].items, startRow)
    end

    mainView:deleteRowsAtSection(section, startRow, endRow, anim)
end)

actionView:setupEdtItemInTime('scrollToCell(row,section,anim)', function (editTextView)
    local indexPathStr = editTextView:text()
    local array = actionView:split(indexPathStr, ',')
    mainView:scrollToCell(tonumber(array[1]), tonumber(array[2]), tonumber(array[3]) == 1)

    local tbl = {'scrollToCell--->', tostring(array[1]), '，', tostring(array[2]), tostring(array[3])}
    actionView:setTestContent(table.concat(tbl))
end)

actionView:setupEdtItemInTime('cellWithSectionRow(section,row)', function (editTextView)
    local indexPathStr = editTextView:text()
    local array = actionView:split(indexPathStr, ',')
    cellText = mainView:cellWithSectionRow(tonumber(array[1]), tonumber(array[2])).textLabel:text()
    local tbl = {'cellWithSectionRow(', array[1], ',', array[2], ')', ' text---->', cellText}
    actionView:setTestContent(table.concat(tbl))
end)


-- ------------------------区分调用方式

actionView:setupDescItemInTime('isRefreshing() 获取', function()
    Toast('isRefreshing() 是否正在刷新 = ' .. tostring(mainView:isRefreshing()))
end)

actionView:setupDescItemInTime('startRefreshing() 开始下拉刷新', function()
    mainView:startRefreshing()
end)

actionView:setupDescItemInTime('isLoading() 是否正在上拉加载', function()
    Toast('isLoading() 是否正在上拉加载 = ' .. tostring(mainView:isLoading()))
end)

insertLabel = Label()
insertLabel:text("插入首位单行"):marginTop(5):marginBottom(5):height(50):marginLeft(20)
insertLabel:bgColor(Color(0, 0, 255, 1))
insertLabel:onClick(function()

    local section = DataSource.sections[1]
    local count = #section.items
    value = {
        type = 'type1',
        text = "被插入的单行",
    }
    table.insert(DataSource.sections[1].items, 1, value)
    mainView:insertRowsAtSection(1, 1, 1, true)
    mainView:scrollToTop(true)
end)
horizonScrollview:addView(insertLabel)

deleteLabel = Label()
deleteLabel:text("删除首位单行"):marginTop(5):marginBottom(5):height(50):marginLeft(20)
deleteLabel:bgColor(Color(0, 0, 255, 1))
deleteLabel:onClick(function()
    local section = DataSource.sections[1]
    local count = #section.items

    table.remove(DataSource.sections[1].items, 1)
    mainView:deleteRowsAtSection(1, 1, 1, true)
    mainView:scrollToTop(true)
end)
horizonScrollview:addView(deleteLabel)

reloadLabel = Label()
reloadLabel:text("刷新首位单行"):marginTop(5):marginBottom(5):height(50):marginLeft(20)
reloadLabel:bgColor(Color(0, 0, 255, 1))
reloadLabel:onClick(function()
    DataSource.sections[1].items[1].text='刷新首位后的文案'
    mainView:reloadAtRow(1, 1,true)
end)
horizonScrollview:addView(reloadLabel)

visibleCellsLabel = Label()
visibleCellsLabel:text("可见视图"):marginTop(5):marginBottom(5):height(50):marginLeft(20)
visibleCellsLabel:bgColor(Color(0, 0, 255, 1))
visibleCellsLabel:onClick(function()
    visibleCells = mainView:visibleCells()
    Toast('可见视图个数 = '..tostring(visibleCells:size()))
end)
horizonScrollview:addView(visibleCellsLabel)

loadThresholdLabel = Label()
loadThresholdLabel:text("loadThreshold 加载更多阈值 0.5"):marginTop(5):marginBottom(5):height(50):marginLeft(20)
loadThresholdLabel:bgColor(Color(0, 0, 255, 1))
loadThresholdLabel:onClick(function()
    mainView:loadThreshold(0.5)
    Toast('loadThreshold 加载更多阈值 0.5')
end)
horizonScrollview:addView(loadThresholdLabel)

openReuseCellLabel = Label()
openReuseCellLabel:text("开启全局cell复用"):marginTop(5):marginBottom(5):height(50):marginLeft(20)
openReuseCellLabel:bgColor(Color(0, 0, 255, 1))
openReuseCellLabel:onClick(function()
    mainView:openReuseCell(true)
    Toast('已开启 全局cell复用')
end)
horizonScrollview:addView(openReuseCellLabel)

pressedColorLabel = Label()
pressedColorLabel:text("获取pressedColor()"):marginTop(5):marginBottom(5):height(50):marginLeft(20)
pressedColorLabel:bgColor(Color(0, 0, 255, 1))
pressedColorLabel:onClick(function()
    Toast('获取pressedColor() = '..tostring(adapter:pressedColor()))
end)
horizonScrollview:addView(pressedColorLabel)

reloadAtSectionLabel = Label()
reloadAtSectionLabel:text("reloadAtSection重新渲染"):marginTop(5):marginBottom(5):height(50):marginLeft(20)
reloadAtSectionLabel:bgColor(Color(0, 0, 255, 1))
reloadAtSectionLabel:onClick(function()
    DataSource.sections[1].items[1].text='重新渲染后的值---'

    mainView:reloadAtSection(1,false)
    Toast('点击了 reloadAtSection重新渲染 ')
end)
horizonScrollview:addView(reloadAtSectionLabel)

insertCellsAtSectionLabel = Label()
insertCellsAtSectionLabel:text("insertCellsAtSection"):marginTop(5):marginBottom(5):height(50):marginLeft(20)
insertCellsAtSectionLabel:bgColor(Color(0, 0, 255, 1))
insertCellsAtSectionLabel:onClick(function()

    value1 = {
        type = 'type1',
        text = "被插入的四行 001",
    }
    value2 = {
        type = 'type1',
        text = "被插入的四行 002",
    }

    local section = DataSource.sections[1]

    table.insert(DataSource.sections[1].items, 1, value1)
    table.insert(DataSource.sections[1].items,  2, value2)

    mainView:insertCellsAtSection(1, 1, 2)
    mainView:scrollToTop(true)
    Toast('点击了 insertCellsAtSection ')
end)
horizonScrollview:addView(insertCellsAtSectionLabel)


deleteCellsAtSectionLabel = Label()
deleteCellsAtSectionLabel:text("deleteCellsAtSection"):marginTop(5):marginBottom(5):height(50):marginLeft(20)
deleteCellsAtSectionLabel:bgColor(Color(0, 0, 255, 1))
deleteCellsAtSectionLabel:onClick(function()


    local section = DataSource.sections[1]
    local count = #section.items

    table.remove(DataSource.sections[1].items, 1)
    table.remove(DataSource.sections[1].items, 1)

    mainView:deleteCellsAtSection(1, 1, 2)
    mainView:scrollToTop(true)

    Toast('点击了 deleteCellsAtSection ')
end)
horizonScrollview:addView(deleteCellsAtSectionLabel)


insertsLabel = Label()
insertsLabel:text("插入4行"):marginTop(5):marginBottom(5):height(50):marginLeft(20)
insertsLabel:bgColor(Color(0, 0, 255, 1))
insertsLabel:onClick(function()

    value1 = {
        type = 'type1',
        text = "被插入的四行 01",
    }
    value2 = {
        type = 'type1',
        text = "被插入的四行 02",
    }
    value3 = {
        type = 'type1',
        text = "被插入的四行 03",
    }
    value4 = {
        type = 'type1',
        text = "被插入的四行 04",
    }

    local section = DataSource.sections[1]
    local count = #section.items

    table.insert(DataSource.sections[1].items, 1, value1)
    table.insert(DataSource.sections[1].items,  2, value2)
    table.insert(DataSource.sections[1].items,  3, value3)
    table.insert(DataSource.sections[1].items,  4, value4)

    mainView:insertRowsAtSection(1,  1,5, true)
    mainView:scrollToTop(true)
end)
horizonScrollview:addView(insertsLabel)

deletesLabel = Label()
deletesLabel:text("删除四行"):marginTop(5):marginBottom(5):height(50):marginLeft(20)
deletesLabel:bgColor(Color(0, 0, 255, 1))
deletesLabel:onClick(function()

    local section = DataSource.sections[1]
    local count = #section.items

    table.remove(DataSource.sections[1].items, 1)
    table.remove(DataSource.sections[1].items, 1)
    table.remove(DataSource.sections[1].items, 1)
    table.remove(DataSource.sections[1].items, 1)
    mainView:deleteRowsAtSection(1, 1, 5, true)
    mainView:scrollToTop(true)

end)
horizonScrollview:addView(deletesLabel)

refreshEnable = true
reloadsLabel = Label()
reloadsLabel:text("是否禁止下拉刷新"):marginTop(5):marginBottom(5):height(50):marginLeft(20)
reloadsLabel:bgColor(Color(0, 0, 255, 1))
reloadsLabel:onClick(function()
    if refreshEnable then
        refreshEnable = false
    else
        refreshEnable = true
    end
    mainView:refreshEnable(refreshEnable)
    reloadsLabel:text("下拉刷新 = "..tostring(refreshEnable))
end)
horizonScrollview:addView(reloadsLabel)


loadEnable = true
loadEnableLabel = Label()
loadEnableLabel:text("是否禁止上拉加载"):marginTop(5):marginBottom(5):height(50):marginLeft(20)
loadEnableLabel:bgColor(Color(0, 0, 255, 1))
loadEnableLabel:onClick(function()
    if loadEnable then
        loadEnable = false
    else
        loadEnable = true
    end
    mainView:loadEnable(loadEnable)
    loadEnableLabel:text("上拉加载 = "..tostring(loadEnable))
end)
horizonScrollview:addView(loadEnableLabel)

isStartPositionLabel = Label()
isStartPositionLabel:text("是否在最顶端"):marginTop(5):marginBottom(5):height(50):marginLeft(20)
isStartPositionLabel:bgColor(Color(0, 0, 255, 1))
isStartPositionLabel:onClick(function()
   Toast('是否在最顶端 = '..tostring(mainView:isStartPosition()))
end)
horizonScrollview:addView(isStartPositionLabel)


setScrollEnable = true
setScrollEnableLabel = Label()
setScrollEnableLabel:text("是否可以滚动"):marginTop(5):marginBottom(5):height(50):marginLeft(20)
setScrollEnableLabel:bgColor(Color(0, 0, 255, 1))
setScrollEnableLabel:onClick(function()
    if setScrollEnable then
        setScrollEnable = false
    else
        setScrollEnable = true
    end
    mainView:setScrollEnable(setScrollEnable)
    setScrollEnableLabel:text(" 滚动 = "..tostring(setScrollEnable))
end)
horizonScrollview:addView(setScrollEnableLabel)


setContentInsetLabel = Label()
setContentInsetLabel:text("设置内边距"):marginTop(5):marginBottom(5):height(50):marginLeft(20)
setContentInsetLabel:bgColor(Color(0, 0, 255, 1))
setContentInsetLabel:onClick(function()
    mainView:setContentInset(20,30,40,30)
    Toast('setContentInset top = 20, right=30,bottom=40,left=30')
end)
horizonScrollview:addView(setContentInsetLabel)


getContentInsetLabel = Label()
getContentInsetLabel:text("获取内边距"):marginTop(5):marginBottom(5):height(50):marginLeft(20)
getContentInsetLabel:bgColor(Color(0, 0, 255, 1))
getContentInsetLabel:onClick(function()
    mainView:getContentInset(function(top,right,bottom,left)
        Toast('getContentInset top = '..tostring(top)..'  right = '..tostring(right)..'  bottom='..tostring(bottom)..'  left='..tostring(left))
    end)
end)
horizonScrollview:addView(getContentInsetLabel)

insertRowLabel = Label()
insertRowLabel:text("insertRow 插入视图"):marginTop(5):marginBottom(5):height(50):marginLeft(20)
insertRowLabel:bgColor(Color(0, 0, 255, 1))
insertRowLabel:onClick(function()

    local section = DataSource.sections[1]
    local count = #section.items
    value = {
        type = 'type1',
        text = "被插入的单行",
    }
    table.insert(DataSource.sections[1].items, 1, value)

    mainView:insertRow(1, 1, false)
    mainView:scrollToTop(true)
    Toast('insertRow 插入视图 insertView(1, 1, false)')
end)
horizonScrollview:addView(insertRowLabel)


deleteRowLabel = Label()
deleteRowLabel:text("deleteRow 删除视图"):marginTop(5):marginBottom(5):height(50):marginLeft(20)
deleteRowLabel:bgColor(Color(0, 0, 255, 1))
deleteRowLabel:onClick(function()

    local section = DataSource.sections[1]
    local count = #section.items

    table.remove(DataSource.sections[1].items, 1)

    mainView:deleteRow(1, 1, false)
    mainView:scrollToTop(true)
    Toast('deleteRow 删除视图 deleteRow(1, 1, false)')
end)
horizonScrollview:addView(deleteRowLabel)




topLinear = LinearLayout(LinearType.HORIZONTAL)
topLinear:setGravity(Gravity.CENTER_HORIZONTAL + Gravity.TOP)
window:addView(topLinear)

mainView:adapter(adapter)
