local ActionsBar = require("MBit.ActionsBar.ActionsBar")
bar = ActionsBar:new(nil):useDefaultSetting()
bar.contentScroll:marginTop(80)
window:addView(bar.contentScroll)

local screen_w = window:width()
local screen_h = window:height()
local TopBarHeight = System:stateBarHeight() + System:navBarHeight()

--- ActionView
local ActionView = require("CollectionView.ActionViews")
local actionView = ActionView:new()
actionView.contentView:marginTop(TopBarHeight + 150):width(screen_w)
window:addView(actionView.contentView)

TopBarHeight = TopBarHeight + actionView.contentView:height()

local titles = { "MBit:band(2,3)",
                 "MBit:bor(2,3)",
                 "MBit:shl(2,3)",
                 "MBit:shr(2,3)",
                 "MBit:bxor(2,3)",
                 "MBit:neg(3)",
}

color3 = Color():setRGBA(200, 180, 250, 1)
infoText = Label():width(MeasurementType.WRAP_CONTENT):height(80):marginLeft(0):marginTop(200 + TopBarHeight):marginRight(20):lines(0):textAlign(TextAlign.CENTER)
infoText:bgColor(color3)
infoText:text('  输出结果显示在这里 ')
window:addView(infoText)

bar:setupTitles(titles)

bar:onClick(function(index, label)
    if index == 1 then
        infoText:text('  MBit:band(2,3) =  ' .. tostring(MBit:band(2, 3)))
    elseif index == 2 then
        infoText:text('  MBit:bor(2,3) =  ' .. tostring(MBit:bor(2, 3)))
    elseif index == 3 then
        infoText:text('  MBit:shl(2,3) =  ' .. tostring(MBit:shl(2, 3)))
    elseif index == 4 then
        infoText:text('  MBit:shr(2,3) =  ' .. tostring(MBit:shr(2, 3)))
    elseif index == 5 then
        infoText:text('  MBit:bxor(2,3) =  ' .. tostring(MBit:bxor(2, 3)))
    elseif index == 6 then
        infoText:text('  MBit:neg(3) =  ' .. tostring(MBit:neg(3)))
    end

end)


--local timer = Timer()
--timer:interval(3)
--timer:repeatCount(#titles)
--
--index = 1
--Toast("执行开始")
--timer:start(function()
--    bar:triggerIndex(index)
--    if index == #titles then
--        Toast("执行结束")
--    end
--    index = index + 1
--
--end)



actionView:setupEdtItemInTime('band ( value1  , valule2 )', function(editTextView)
    local indexPathStr = editTextView:text()
    local array = actionView:split(indexPathStr, ',')

    print(tonumber(array[1]), ' type = ', type(tonumber(array[1])))

    result = tostring(MBit:band(tonumber(array[1]), tonumber(array[2])))
    infoText:text('band ( ' .. array[1] .. '  ,  ' .. array[2] .. ' ) ' .. ')   result  =  ' .. result)

    actionView:setTestContent(infoText:text())
end)

actionView:setupEdtItemInTime('bor ( value1  , valule2 )', function(editTextView)
    local indexPathStr = editTextView:text()
    local array = actionView:split(indexPathStr, ',')

    result = tostring(MBit:bor(tonumber(array[1]), tonumber(array[2])))
    infoText:text('bor ( ' .. array[1] .. '  ,  ' .. array[2] .. ' ) ' .. ')   result  =  ' .. result)

    actionView:setTestContent(infoText:text())
end)

actionView:setupEdtItemInTime('shl ( value1  , valule2 )', function(editTextView)
    local indexPathStr = editTextView:text()
    local array = actionView:split(indexPathStr, ',')

    result = tostring(MBit:shl(tonumber(array[1]), tonumber(array[2])))
    infoText:text('shl ( ' .. array[1] .. '  ,  ' .. array[2] .. ' ) ' .. ')   result  =  ' .. result)

    actionView:setTestContent(infoText:text())
end)

actionView:setupEdtItemInTime('shr ( value1  , valule2 )', function(editTextView)
    local indexPathStr = editTextView:text()
    local array = actionView:split(indexPathStr, ',')

    result = tostring(MBit:shr(tonumber(array[1]), tonumber(array[2])))
    infoText:text('shr ( ' .. array[1] .. '  ,  ' .. array[2] .. ' ) ' .. ')   result  =  ' .. result)

    actionView:setTestContent(infoText:text())
end)

actionView:setupEdtItemInTime('bxor ( value1  , valule2 )', function(editTextView)
    local indexPathStr = editTextView:text()
    local array = actionView:split(indexPathStr, ',')

    result = tostring(MBit:bxor(tonumber(array[1]), tonumber(array[2])))
    infoText:text('bxor ( ' .. array[1] .. '  ,  ' .. array[2] .. ' ) ' .. ')   result  =  ' .. result)

    actionView:setTestContent(infoText:text())
end)

actionView:setupEdtItemInTime('neg ( value1  )', function(editTextView)
    local indexPathStr = editTextView:text()
    local array = actionView:split(indexPathStr, ',')

    result = tostring(MBit:neg(tonumber(array[1])))
    infoText:text('neg ( ' .. array[1] .. ' ) ' .. ')   result  =  ' .. result)

    actionView:setTestContent(infoText:text())
end)

local ahex = 0xceff63e7
local a = MBit:band(MBit:shr(ahex, 24), 0xff) / 0xFF
local r = MBit:band(MBit:shr(ahex, 16), 0xff)
local g = MBit:band(MBit:shr(ahex, 8), 0xff)
local b = MBit:band(MBit:shr(ahex, 0), 0xff)

print("a=", a, ",r=", r, ",g=", g, ",b=", b)
Toast("result：" .. "a=" .. a .. ",r=" .. r .. ",g=" .. g .. ",b=" .. b)






