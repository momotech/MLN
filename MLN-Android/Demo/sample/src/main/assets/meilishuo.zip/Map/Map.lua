--local baseView = require("view.baseViewutils.BaseView")
Red = Color(255, 0, 0, 1)
Green = Color(0, 255, 0, 1)
Green30 = Color(0, 255, 0, 0.3)
Blue = Color(0, 0, 255, 1)
Blue30 = Color(0, 0, 255, 0.3)
Black = Color(0, 0, 0, 1)
Black30 = Color(0, 0, 0, 0.3)

local window = window

local statusBarHeight = System:stateBarHeight()
local navBarHeight = 0
if System:iOS() then
    navBarHeight = System:navBarHeight()
    window:padding(navBarHeight + statusBarHeight, 0, 0, 0)
end
local screenSize = System:screenSize()

screenW = screenSize:width() - 2
screenH = screenSize:height() - 2 - statusBarHeight - navBarHeight

itemHeight = screenH / 14

window:bgColor(Black)
local ViewL = View():height(screenH):width(screenW / 2):bgColor(Color(255, 255, 255, 1))
local ViewR = LinearLayout(LinearType.VERTICAL):height(screenH):width(screenW / 2):setGravity(Gravity.RIGHT):bgColor(Color(255, 255, 255, 1))
window:addView(ViewL)
window:addView(ViewR)


local mMap = Map()

local label = EditTextView():width(MeasurementType.MATCH_PARENT):height(MeasurementType.MATCH_PARENT):bgColor(Green30):text("Map 的内容")
ViewL:addView(label)

local keyValue = LinearLayout(LinearType.HORIZONTAL):width(MeasurementType.MATCH_PARENT):height(MeasurementType.WRAP_CONTENT):marginBottom(5):marginTop(30)
ViewR:addView(keyValue)
local key = EditTextView():padding(5, 15, 5, 15):text("key"):width(screenW / 4 - 5):height(MeasurementType.WRAP_CONTENT):bgColor(Black30)
keyValue:addView(key)
local value = EditTextView():padding(5, 15, 5, 15):text("value"):marginLeft(10):width(screenW / 4 - 5):height(MeasurementType.WRAP_CONTENT):bgColor(Black30)
keyValue:addView(value)

local put = Label():padding(5, 15, 5, 15):text("put string"):width(screenW / 2):height(MeasurementType.WRAP_CONTENT):bgColor(Blue30)
put:onClick(function()
    mMap:put(key:text(), value:text())
    label:text(tostring(mMap))
end)
ViewR:addView(put)

local put = Label():padding(5, 15, 5, 15):text("put number"):width(screenW / 2):height(MeasurementType.WRAP_CONTENT):bgColor(Blue30)
put:onClick(function()
    mMap:put(key:text(), 1)
    label:text(tostring(mMap))
end)
ViewR:addView(put)

local putAll = Label():padding(5, 15, 5, 15):text("putAll"):width(screenW / 2):height(MeasurementType.WRAP_CONTENT):bgColor(Blue30)
putAll:onClick(function()
    local allMap = Map()
    allMap:put("all1", "全部1")
    allMap:put("all2", "全部2")
    allMap:put("all3", "全部3")
    mMap:putAll(allMap)
    label:text(tostring(mMap))
end)
ViewR:addView(putAll)

local remove = Label():padding(5, 15, 5, 15):text("remove"):width(screenW / 2):height(MeasurementType.WRAP_CONTENT):bgColor(Blue30)
remove:onClick(function()
    mMap:remove(key:text())
    label:text(tostring(mMap))
end)
ViewR:addView(remove)

local removeAll = Label():padding(5, 15, 5, 15):text("removeAll"):width(screenW / 2):height(MeasurementType.WRAP_CONTENT):bgColor(Blue30)
removeAll:onClick(function()
    mMap:removeAll()
    label:text(tostring(mMap))
end)
ViewR:addView(removeAll)

local get = Label():padding(5, 15, 5, 15):text("get"):width(screenW / 2):height(MeasurementType.WRAP_CONTENT):bgColor(Blue30)
get:onClick(function()
    label:text(tostring(mMap:get(key:text())).."\n type: "..type(mMap:get(key:text())))
end)
ViewR:addView(get)

local size = Label():padding(5, 15, 5, 15):text("size"):width(screenW / 2):height(MeasurementType.WRAP_CONTENT):bgColor(Blue30)
size:onClick(function()
    label:text(tostring(mMap:size()))
end)
ViewR:addView(size)

local allKeys = Label():padding(5, 15, 5, 15):text("allKeys"):width(screenW / 2):height(MeasurementType.WRAP_CONTENT):bgColor(Blue30)
allKeys:onClick(function()
    label:text(tostring(mMap:allKeys()))
end)
ViewR:addView(allKeys)

local removeObjects = Label():padding(5, 15, 5, 15):lines(2):text("removeObjects (与2一起测)"):width(screenW / 2):height(MeasurementType.WRAP_CONTENT):bgColor(Blue30)
removeObjects:onClick(function()
    local keyArray = Array()
    keyArray:add("all1")
    keyArray:add("all2")
    keyArray:add("all3")

    label:text(tostring(mMap:removeObjects(keyArray)))
end)
ViewR:addView(removeObjects)


local arrayRoot = LinearLayout(LinearType.HORIZONTAL):width(MeasurementType.MATCH_PARENT):height(MeasurementType.WRAP_CONTENT):marginBottom(5):marginTop(20)
ViewR:addView(arrayRoot)

local addArray = Label():padding(5, 15, 5, 15):text("addArray"):width(screenW / 4):height(MeasurementType.WRAP_CONTENT):bgColor(Blue30)
addArray:onClick(function()
    local array = Array()
    array:add("one")
    array:add("two")
    array:add("three")
    array:add("four")
    array:add("five")
    mMap:put("array", array)

    label:text(tostring(mMap))
end)
arrayRoot:addView(addArray)

local isArray = Label():padding(5, 15, 5, 15):text("isArray"):width(screenW / 4 - 10):height(MeasurementType.WRAP_CONTENT):bgColor(Blue30):marginLeft(10)
isArray:onClick(function()
    local array = mMap:get("array")

    label:text("key array \n 取出的数据，isArray：" .. tostring(TypeUtils:isArray(array)))
end)
arrayRoot:addView(isArray)

local MapRoot = LinearLayout(LinearType.HORIZONTAL):width(MeasurementType.MATCH_PARENT):height(MeasurementType.WRAP_CONTENT):marginBottom(5):marginTop(20)
ViewR:addView(MapRoot)

local addMap = Label():padding(5, 15, 5, 15):text("addMap"):width(screenW / 4):height(MeasurementType.WRAP_CONTENT):bgColor(Blue30)
addMap:onClick(function()
    local map = Map()
    map:put("1", "one")
    map:put("2", "two")
    map:put("3", "three")
    map:put("4", "four")
    map:put("5", "five")
    mMap:put("map", map)

    label:text(tostring(mMap))
end)
MapRoot:addView(addMap)

local isMap = Label():padding(5, 15, 5, 15):text("isMap"):width(screenW / 4 - 10):height(MeasurementType.WRAP_CONTENT):bgColor(Blue30):marginLeft(10)
isMap:onClick(function()
    local map = mMap:get("map")

    label:text("key: map \n 取出的数据，isMap：" .. tostring(TypeUtils:isMap(map)))
end)
MapRoot:addView(isMap)

