

-- 示例：有状态的图片按钮（继承View）

local width = window:width()
local btn = ImageButton()

btn:frame(Rect(18, 100, width - 36, 115))
btn:setImage("https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=1159386606,974071300&fm=200&gp=0.jpg", "https://moji.wemomo.com/attach/pimg_5b5703e8c769c.png")
btn:bgColor(Color(121, 14, 54, 1.0))
btn:padding(5, 10, 15, 20)

btn:onClick(function()
    Toast("onClick ", 0.5)
end)

window:addView(btn)
