
-- 创建http对象，使用缓存策略CachePolicy，默认忽略lat、lng、net等指定key
function createHttp()
    http = Http()
    http:addCachePolicyFilterKey('lat')
    http:addCachePolicyFilterKey('lng')
    http:addCachePolicyFilterKey('net')
    return http
end
