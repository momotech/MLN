--- Http
--- 实现案例
---'


http = Http()
http:setBaseUrl("http://api.immomo.com")
postParams = Map()
isCache = false

function createCommonTabLinearLayout(contentView, bgColor)
    local btnScrollView = ScrollView(true)

    btnScrollView:height(50)
    btnScrollView:width(350)

    if bgColor then
        btnScrollView:bgColor(bgColor)
    end

    contentView:addView(btnScrollView)

    local btnsContainer = LinearLayout(LinearType.HORIZONTAL):height(50):setWrapContent(true)
    btnScrollView:addView(btnsContainer)

    return btnsContainer
end

function addTabFromData(dataSource, tabsContainer)

    local tabs = {}
    for i, v in ipairs(dataSource) do
        local start, last = string.find(v, "demo.")
        local name
        if last and last < #v then
            name = string.sub(v, last + 1, #v)
        else
            name = v
        end
        local tab = Label():setAutoFit(true):textAlign(TextAlign.CENTER):setMinWidth(80):marginLeft(5):padding(0, 5, 5, 5):height(50):fontSize(14):text(name):bgColor(Color(211, 211, 211, 1)):textColor(Color(0, 0, 0, 1))
        tabsContainer:addView(tab)
        tabs[v] = tab
    end

    return tabs
end

function initShowLabel(showLabel, width, height)
    showLabel:width(width - 16):height(height - (16 + (40 + 5) * 3) - 8):singleLine(false):fontSize(20):textAlign(TextAlign.LEFT):textColor(Color(0, 0, 0, 1)):bgColor(Color(222, 222, 222, 1)):y(16 + (40 + 5) * 3):x(8):textColor(Color(0, 0, 0, 1))
    return showLabel
end

function onCreate(contentView)

    local width = contentView:width()
    local height = contentView:height()

    local showLabel = EditTextView()  --显示结果

    --CachePolicy {
    --    API_ONLY = 0,               -- 不使用缓存,只从网络更新数据
    --    CACHE_THEN_API,             -- 先使用缓存，随后请求网络更新请求
    --    CACHE_OR_API,               -- 优先使用缓存，无法找到缓存时才连网更新
    --    CACHE_ONLY,                 -- 只读缓存
    --    REFRESH_CACHE_BY_API        -- 刷新网络后数据加入缓存
    --}




    function sendRightUrl(url)

        showLabel:text("请求中...." .. tostring(postParams))

        http:post(url, postParams, function(success, resp, error)
            postParams = Map()
            if success and resp then
                print("keye keye", resp:get("__isCache"))
                if resp:get("__isCache") then
                    isCache = true
                end

                showLabel:text("cachePolicy：" .. tostring(postParams:get("cachePolicy")) .. "\n\nencType：" .. tostring(postParams:get("encType")) .. "\n\nUrl: " .. tostring(url) .. "\n\nsuccess: " .. tostring(success) .. "\n\nhasCache: " .. tostring(isCache) .. "\n\nreps: \n" .. tostring(resp))
            else
                showLabel:text("cachePolicy：" .. tostring(postParams:get("cachePolicy")) .. "\n\nencType：" .. tostring(postParams:get("encType")) .. "\n\nUrl: " .. tostring(url) .. "\n\nsuccess: " .. tostring(success) .. "\n\nerror: \n" .. tostring(error))
            end
        end)
    end

    function downloadSB(url)

        showLabel:text("下载中...." .. tostring(postParams))

        http:download(url, postParams,
                function(progress, total)
                    showLabel:text(showLabel:text() .. "\n进度：" .. tostring(progress) .. ", " .. tostring(total))
                end,
                function(success, resp, error)
                    postParams = Map()
                    if success and resp then
                        showLabel:text(showLabel:text() .. "\n\nUrl: " .. tostring(url) .. "\n\nsuccess: " .. tostring(success) .. "\n\nreps: \n" .. tostring(resp))
                    else
                        showLabel:text(showLabel:text() .. "\n\nUrl: " .. tostring(url) .. "\n\nsuccess: " .. tostring(success) .. "\n\nerror: \n" .. tostring(error))
                    end
                end)
    end

    function upload(url, filePaths, parameterNames)

        showLabel:text("下载中...." .. tostring(postParams))

        http:upload(url, postParams, filePaths, parameterNames,
                function(success, resp, error)
                    postParams = Map()
                    if success and resp then
                        showLabel:text(showLabel:text() .. "\n\nUrl: " .. tostring(url) .. "\n\nsuccess: " .. tostring(success) .. "\n\nreps: \n" .. tostring(resp))
                    else
                        showLabel:text(showLabel:text() .. "\n\nUrl: " .. tostring(url) .. "\n\nsuccess: " .. tostring(success) .. "\n\nerror: \n" .. tostring(error))
                    end
                end)
    end



    ----以下代码不用管，显示UI用的
    local btnInfo = { "正确请求", "错误请求", "空param", "Download", "upload" }

    --初始化view
    local Desc = Label():text("请用陌陌客户端扫码测试"):fontSize(19):setAutoFit(true):height(40):textAlign(TextAlign.CENTER):textColor(Color(0, 0, 0, 1)):x(10):y(50)
    contentView:addView(Desc)
    contentView:addView(initShowLabel(showLabel, width, height))

    local tabsContainer = createCommonTabLinearLayout(contentView)
    local tabs = addTabFromData(btnInfo, tabsContainer)

    for i, v in pairs(tabs) do
        if i == btnInfo[1] then
            v:onClick(function()
                postParams:put("cachePolicy", 1)
                postParams:put("encType", EncType.NORMAL)
                http:setBaseUrl("http://api.immomo.com")
                sendRightUrl("v1/nearby/index")
            end)
        elseif i == btnInfo[2] then
            v:onClick(function()
                postParams:put("cachePolicy", 1)
                postParams:put("encType", EncType.NORMAL)
                http:setBaseUrl("")
                sendRightUrl("www.baidu.com")
            end)
        elseif i == btnInfo[3] then
            v:onClick(function()
                postParams = nil
                http:setBaseUrl("http://api.immomo.com")
                sendRightUrl("v1/nearby/index")
            end)
        elseif i == btnInfo[4] then
            v:onClick(function()
                postParams:put("__path", "file://lua_download_test/testimage.jpg")
                http:setBaseUrl("")
                downloadSB("http://m.imeitou.com/uploads/allimg/2018082719/vvummeh5ie4.jpg")
            end)
        elseif i == btnInfo[5] then
            v:onClick(function()
                local fileKey = "photo_upload"
                local postDict = Map()
                        :put("key", "photo_upload")
                        :put("upload", "NO")

                local photoArray = Array():add(postDict)
                postParams:put("photos", StringUtil:arrayToJSON(photoArray))
                postParams:put("confirm", 0)

                local filePaths = Array()
                filePaths:add("file://lua_download_test/testimage.jpg")
                local parameterNames = Array()
                parameterNames:add(fileKey)

                http:setBaseUrl("")
                upload("http://api.immomo.com/v2/match/user/saveProfile", filePaths, parameterNames)
            end)
        end
    end

end

onCreate(window)
