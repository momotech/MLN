
local editTextView = EditTextView():width(MeasurementType.MATCH_PARENT):height(80):bgColor(Color(240,248,255, 1)):marginTop(100)
editTextView:textColor(Color(0, 0, 0, 1)):marginLeft(5):priority(1)
editTextView:placeholder('输入要展示的时长')
editTextView:setMinWidth(100):cornerRadius(2)
window:addView(editTextView)

local linear = LinearLayout(LinearType.VERTICAL):marginTop(180):width(MeasurementType.MATCH_PARENT):height(MeasurementType.WRAP_CONTENT)
window:addView(linear)


local shoToastLabel = Label()
linear:addView(shoToastLabel)
shoToastLabel:marginTop(5):width(MeasurementType.WRAP_CONTENT):height(50)
shoToastLabel:fontSize(16)
shoToastLabel:text("Toast 自定义时长，点击展示")

shoToastLabel:bgColor(Color():hex(0xffaa00):alpha(1))

shoToastLabel:onClick(function()

    local text = editTextView:text();
    if text == '' then
        Toast("Toast 展示 1",0)
    elseif tonumber(text) ~= nil then

        Toast("Toast 展示 2ddddddddddd",tonumber(editTextView:text()))
    else
        Toast("请输入数字...",1)
    end

end)



local longTimeLabel = Label()
linear:addView(longTimeLabel)
longTimeLabel:marginTop(5):width(MeasurementType.WRAP_CONTENT):height(50)
longTimeLabel:fontSize(16)
longTimeLabel:text("Toast 1s展示")

longTimeLabel:bgColor(Color():hex(0xffaa00):alpha(1))

longTimeLabel:onClick(function()
    Toast("lalalalallalsalal展示",1)

end)



local shortTimeLabel = Label()
linear:addView(shortTimeLabel)
shortTimeLabel:marginTop(5):width(MeasurementType.WRAP_CONTENT):height(50)
shortTimeLabel:fontSize(16)
shortTimeLabel:text("Toast 短时间展示")

shortTimeLabel:bgColor(Color():hex(0xffaa00):alpha(1))

shortTimeLabel:onClick(function()

    Toast("Toast 短时间展示",0)

end)
