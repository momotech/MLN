--- Loads `luacov.runner` and immediately starts it.
-- Useful for launching scripts from the command-line. Returns the `luacov.runner` module.
-- @class module
-- @name luacov
-- @usage lua -lluacov sometest.lua

--local homePath = os.getenv("HOME")
local runner = require("MLNCodeCoverage.runner")
runner.init()
return runner
